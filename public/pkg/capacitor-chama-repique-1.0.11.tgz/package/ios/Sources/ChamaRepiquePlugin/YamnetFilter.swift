import Foundation
import TensorFlowLiteC

/// YAMNet percussion filter. Rejects non-percussion audio before classification.
/// Ported from yamnet_filter.dart.
class YamnetFilter {
    private var interpreter: OpaquePointer? // TfLiteInterpreter
    private var model: OpaquePointer? // TfLiteModel

    // Percussion class indices in YAMNet (AudioSet ontology)
    // Range 156-175 = Percussion instruments, 213 = Beatboxing
    private static let percussionIndices: [Int] = Array(156...175) + [213]
    private static let percussionThreshold: Float = 0.02
    private static let yamnetSampleRate = 16000
    private static let originalSampleRate = 44100
    private static let yamnetInputLength = 15600 // 0.975s @ 16kHz

    func load() -> Bool {
        guard let path = ChamaRepiquePlugin.resourceBundle.path(forResource: "yamnet", ofType: "tflite") else {
            print("[YAMNet] Model file not found")
            return false
        }

        model = TfLiteModelCreateFromFile(path)
        guard model != nil else {
            print("[YAMNet] Failed to create model")
            return false
        }

        let options = TfLiteInterpreterOptionsCreate()
        TfLiteInterpreterOptionsSetNumThreads(options, 1)
        interpreter = TfLiteInterpreterCreate(model, options)
        TfLiteInterpreterOptionsDelete(options)

        guard interpreter != nil else {
            print("[YAMNet] Failed to create interpreter")
            return false
        }

        let status = TfLiteInterpreterAllocateTensors(interpreter)
        guard status == kTfLiteOk else {
            print("[YAMNet] Failed to allocate tensors")
            return false
        }

        // Warmup: pre-aqueça o graph (1ª inference é ~2-3x mais lenta).
        // Mirror Python identify_chamada.py:_warmup.
        let dummy = [Float](repeating: 0.001, count: Self.originalSampleRate)
        _ = isPercussion(dummy)
        print("[YAMNet] Model loaded OK + warmup")
        return true
    }

    /// Returns true if the audio contains percussion.
    /// audio is float32 mono at 44100Hz.
    func isPercussion(_ audio: [Float]) -> Bool {
        guard let interpreter = interpreter else { return true } // fail-open
        guard audio.count >= 4410 else { return false }

        // Resample 44100 → 16000
        let resampled = resample(audio, from: Self.originalSampleRate, to: Self.yamnetSampleRate)

        // Take last 15600 samples (or pad with zeros)
        var input = [Float](repeating: 0, count: Self.yamnetInputLength)
        if resampled.count >= Self.yamnetInputLength {
            let offset = resampled.count - Self.yamnetInputLength
            input = Array(resampled[offset...])
        } else {
            let offset = Self.yamnetInputLength - resampled.count
            for i in 0..<resampled.count {
                input[offset + i] = resampled[i]
            }
        }

        // Copy to input tensor
        let inputTensor = TfLiteInterpreterGetInputTensor(interpreter, 0)
        input.withUnsafeBufferPointer { ptr in
            TfLiteTensorCopyFromBuffer(inputTensor, ptr.baseAddress!, ptr.count * MemoryLayout<Float>.size)
        }

        // Run inference
        let status = TfLiteInterpreterInvoke(interpreter)
        guard status == kTfLiteOk else { return true }

        // Read output — [1, 521]
        let outputTensor = TfLiteInterpreterGetOutputTensor(interpreter, 0)
        var scores = [Float](repeating: 0, count: 521)
        scores.withUnsafeMutableBufferPointer { ptr in
            TfLiteTensorCopyToBuffer(outputTensor, ptr.baseAddress!, ptr.count * MemoryLayout<Float>.size)
        }

        // Sum percussion scores
        var percScore: Float = 0
        for idx in Self.percussionIndices where idx < 521 {
            percScore += scores[idx]
        }

        return percScore >= Self.percussionThreshold
    }

    /// Linear interpolation resample.
    private func resample(_ input: [Float], from fromRate: Int, to toRate: Int) -> [Float] {
        let ratio = Double(fromRate) / Double(toRate)
        let outLen = Int(Double(input.count) / ratio)
        var output = [Float](repeating: 0, count: outLen)
        for i in 0..<outLen {
            let srcPos = Double(i) * ratio
            let idx = Int(srcPos)
            let frac = Float(srcPos - Double(idx))
            if idx + 1 < input.count {
                output[i] = input[idx] * (1.0 - frac) + input[idx + 1] * frac
            } else {
                output[i] = input[min(idx, input.count - 1)]
            }
        }
        return output
    }

    func dispose() {
        if let interpreter = interpreter {
            TfLiteInterpreterDelete(interpreter)
        }
        if let model = model {
            TfLiteModelDelete(model)
        }
        interpreter = nil
        model = nil
    }
}
