import Foundation
import TensorFlowLiteC

/// CNN onset detector — wrapper de `onset_cnn.tflite`.
///
/// Modelo: 4-layer Conv2D + BiLSTM 2-layer + Linear sigmoid (~2.87M params).
/// Treinado em `scripts/modal_train_onset_cnn.py` com pseudo-labels do master
/// + iPhone pairs, augmentation com noise injection. F1 val 0.79.
///
/// Input fixo: (1, 128, 200) — 2s @ 100Hz com 128 mel bands.
/// Output: (1, 200) — sigmoid prob por frame de 10ms.
///
/// Para áudio mais comprido, faz sliding window de 2s sem overlap (stride
/// 88200 samples, zero-pad no fim). Para áudio < 2s, zero-pad inicial.
///
/// Mirror de `scripts/onset_cnn_inference.py:OnsetCNNDetector`.
final class OnsetCNN {
    private var interpreter: OpaquePointer?
    private var model: OpaquePointer?
    private var state: OpaquePointer?

    /// Threshold sigmoid mínimo para considerar peak. Default 0.5 (Python).
    var threshold: Float = 0.5
    /// Distância mínima entre peaks consecutivos em ms. Default 50ms (Python).
    var minDistanceMs: Int = 50

    /// True após `load()` bem-sucedido. Caller pode usar para fallback.
    private(set) var isLoaded: Bool = false

    func load() -> Bool {
        state = repenique_onset_init()
        guard state != nil else {
            print("[OnsetCNN] repenique_onset_init failed")
            return false
        }
        guard let path = ChamaRepiquePlugin.resourceBundle.path(forResource: "onset_cnn", ofType: "tflite") else {
            print("[OnsetCNN] onset_cnn.tflite not found in bundle")
            return false
        }
        model = TfLiteModelCreateFromFile(path)
        let opts = TfLiteInterpreterOptionsCreate()
        TfLiteInterpreterOptionsSetNumThreads(opts, 2)
        interpreter = TfLiteInterpreterCreate(model, opts)
        TfLiteInterpreterOptionsDelete(opts)
        guard interpreter != nil,
              TfLiteInterpreterAllocateTensors(interpreter) == kTfLiteOk else {
            print("[OnsetCNN] interpreter init failed")
            return false
        }
        isLoaded = true
        // Warmup: 1ª invoke do CNN é ~2-3x mais lenta (graph dispatch + cache cold).
        // Mirror Python identify_chamada.py:_warmup (extract_tubs com onset_engine=cnn).
        let dummy = [Float](repeating: 0.001, count: Int(REPENIQUE_ONSET_WIN_SAMPLES))
        _ = detect(audio: dummy)
        print("[OnsetCNN] Loaded onset_cnn.tflite (input 1×128×200) + warmup")
        return true
    }

    func dispose() {
        if let interpreter = interpreter { TfLiteInterpreterDelete(interpreter) }
        if let model = model { TfLiteModelDelete(model) }
        if let st = state { repenique_onset_free(st) }
        interpreter = nil
        model = nil
        state = nil
        isLoaded = false
    }

    /// Detecta onsets. Retorna lista de tempos em segundos (ascendente).
    /// Audio: float32 mono @ 44100Hz.
    /// Mirror Python `OnsetCNNDetector.detect`.
    func detect(audio: [Float]) -> [Double] {
        guard isLoaded else { return [] }
        let probs = computeProbs(audio: audio)
        if probs.isEmpty { return [] }
        let minDistFrames = max(1, minDistanceMs / 10)  // 10ms per frame
        return pickPeaks(probs: probs, threshold: threshold, minDistanceFrames: minDistFrames)
    }

    /// Computa probs por 10ms-frame para a duração total do áudio. Sliding
    /// window de 2s sem overlap; zero-pad no fim do último window.
    private func computeProbs(audio: [Float]) -> [Float] {
        let t0 = Date().timeIntervalSince1970

        let win = Int(REPENIQUE_ONSET_WIN_SAMPLES)   // 88200
        let frames = Int(REPENIQUE_ONSET_WIN_FRAMES) // 200
        let hop = Int(REPENIQUE_ONSET_HOP)           // 441

        let nFramesTotal = max(1, audio.count / hop)
        // Quantos windows precisamos para cobrir todo o audio (ceil)
        let nWindows = max(1, (audio.count + win - 1) / win)
        var allProbs = [Float](repeating: 0, count: nWindows * frames)

        var windowed = [Float](repeating: 0, count: win)
        var winMs: [Double] = []

        for w in 0..<nWindows {
            let wStart = Date().timeIntervalSince1970
            let start = w * win
            let end = min(start + win, audio.count)
            // Reset window buffer; copy slice of audio + zero pad
            for i in 0..<win { windowed[i] = 0 }
            if end > start {
                let take = end - start
                for i in 0..<take { windowed[i] = audio[start + i] }
            }
            // For audio shorter than 2s, the single window already has zeros.
            if let probs = inferOneWindow(windowed) {
                let off = w * frames
                for f in 0..<frames {
                    allProbs[off + f] = probs[f]
                }
            }
            winMs.append((Date().timeIntervalSince1970 - wStart) * 1000)
        }

        let totalMs = (Date().timeIntervalSince1970 - t0) * 1000
        // Log se >= 30ms (single window) ou multi-window
        if totalMs >= 30 || nWindows > 1 {
            let perWin = winMs.map { String(format: "%.0f", $0) }.joined(separator: ",")
            print("[OnsetCNN] computeProbs n=\(audio.count) windows=\(nWindows) [\(perWin)ms] total=\(String(format: "%.0f", totalMs))ms")
        }

        // Truncate to actual frames (Python: probs[:n_frames_total])
        let limit = min(nFramesTotal, allProbs.count)
        return Array(allProbs[0..<limit])
    }

    /// Mel-spec via native (128×200) + TFLite invoke + sigmoid → 200 probs.
    private func inferOneWindow(_ audio: [Float]) -> [Float]? {
        guard let st = state, let interp = interpreter else { return nil }

        var mel = [Float](repeating: 0, count: Int(REPENIQUE_ONSET_OUT_SIZE))
        let rc = audio.withUnsafeBufferPointer { audioPtr in
            mel.withUnsafeMutableBufferPointer { melPtr in
                repenique_onset_mel_spec(st, audioPtr.baseAddress!, melPtr.baseAddress!)
            }
        }
        guard rc == 0 else {
            print("[OnsetCNN] mel_spec rc=\(rc)")
            return nil
        }

        let inT = TfLiteInterpreterGetInputTensor(interp, 0)
        mel.withUnsafeBufferPointer { ptr in
            TfLiteTensorCopyFromBuffer(inT, ptr.baseAddress!, ptr.count * MemoryLayout<Float>.size)
        }
        guard TfLiteInterpreterInvoke(interp) == kTfLiteOk else {
            return nil
        }

        let outT = TfLiteInterpreterGetOutputTensor(interp, 0)
        var logits = [Float](repeating: 0, count: Int(REPENIQUE_ONSET_WIN_FRAMES))
        logits.withUnsafeMutableBufferPointer { ptr in
            TfLiteTensorCopyToBuffer(outT, ptr.baseAddress!, ptr.count * MemoryLayout<Float>.size)
        }
        // Sigmoid in-place
        for i in 0..<logits.count {
            logits[i] = 1.0 / (1.0 + expf(-logits[i]))
        }
        return logits
    }

    /// Peak picking equivalent a `scipy.signal.find_peaks(probs, height=threshold,
    /// distance=min_distance_frames)`. Algoritmo:
    /// 1) Local maxima estritos (probs[i] > probs[i-1] AND >= probs[i+1]) acima do threshold.
    /// 2) Sort por height descendente.
    /// 3) Greedy accept: skipa se conflita com peak já aceite (distância < min).
    /// 4) Return ordenado por tempo (ascendente).
    /// Retorna tempos em segundos (frame * 0.01s).
    private func pickPeaks(probs: [Float], threshold: Float, minDistanceFrames: Int) -> [Double] {
        guard probs.count >= 3, minDistanceFrames >= 1 else { return [] }

        var candidates: [Int] = []
        for i in 1..<(probs.count - 1) {
            if probs[i] < threshold { continue }
            if probs[i] <= probs[i - 1] { continue }
            if probs[i] < probs[i + 1] { continue }
            candidates.append(i)
        }
        if candidates.isEmpty { return [] }

        // Sort by height descending
        candidates.sort { probs[$0] > probs[$1] }

        var accepted: [Int] = []
        accepted.reserveCapacity(candidates.count)
        for c in candidates {
            var conflict = false
            for a in accepted {
                if abs(c - a) < minDistanceFrames {
                    conflict = true
                    break
                }
            }
            if !conflict { accepted.append(c) }
        }
        accepted.sort()

        // 10ms per frame
        return accepted.map { Double($0) / 100.0 }
    }
}
