import Foundation
import AVFoundation

/// Plays response patterns using real repique samples.
///
/// Sample pools:
/// - **Regular** (4 samples, `repique-1.wav`...`repique-4.wav`): hits regulares.
///   Rotação queue evita os últimos 2 picks consecutivos (sem efeito metralhadora).
/// - **Ending** (2 samples, `repique-end-1.wav`, `repique-end-2.wav`): hits de
///   fim de sequência. Random pick.
///
/// Notação na pauta resolvida (ver `CanonicalLibrary.resolveResposta`):
/// - `X` = regular hit → regular pool com rotação
/// - `x` = ending hit → ending pool
/// - `.` = silêncio
/// - O ÚLTIMO onset de qualquer pattern é sempre tratado como ending,
///   mesmo que esteja como `X` (fallback automático).
///
/// Volume: regular ±2dB random, ending 0..+2dB random.
/// Peak limit: post-render, atenua para 0.95 se houver clipping (respostas densas).
class PlaybackEngine {
    private static let sampleRate = 44100
    private static let defaultBpm: Double = 130.0

    private static let regularSampleNames = ["repique-1", "repique-2", "repique-3", "repique-4"]
    private static let endingSampleNames = ["repique-end-1", "repique-end-2"]
    private static let surdoSampleName = "surdo"

    private var player: AVAudioPlayer?
    private var regularSamples: [[Float]] = []
    private var endingSamples: [[Float]] = []
    private var surdoSample: [Float] = []
    private var recentRegular: [Int] = []   // últimos 2 picks do regular pool
    private var tempDir: String?

    /// Gain do surdo layer em dB (negativo = mais subtil). Default -6dB.
    private static let surdoGainDb: Float = -6.0
    /// Cauda do surdo: cortar a 1.5s com 300ms fade-out linear (decay smooth).
    private static let surdoKeepSeconds: Double = 1.5
    private static let surdoFadeSeconds: Double = 0.30

    // Pre-rendered response
    private var preRenderedChamada: String?
    private var preRenderedPath: String?

    func load() -> Bool {
        tempDir = NSTemporaryDirectory()

        for name in Self.regularSampleNames {
            guard let pcm = loadSample(named: name) else { return false }
            regularSamples.append(pcm)
        }
        for name in Self.endingSampleNames {
            guard let pcm = loadSample(named: name) else { return false }
            endingSamples.append(pcm)
        }
        if let raw = loadSample(named: Self.surdoSampleName) {
            surdoSample = trimSurdoTail(raw)
        } else {
            ChamaRepiqueLog.log("Playback", "surdo.wav não encontrado — layer desactivado")
        }

        ChamaRepiqueLog.log("Playback", "Loaded \(regularSamples.count) regular + \(endingSamples.count) ending + surdo (\(surdoSample.count) samples)")
        return true
    }

    /// Aplica corte ~1.5s + fade-out 300ms à cauda do surdo (decay smooth).
    private func trimSurdoTail(_ raw: [Float]) -> [Float] {
        let keepN = Int(Self.surdoKeepSeconds * Double(Self.sampleRate))
        let fadeN = Int(Self.surdoFadeSeconds * Double(Self.sampleRate))
        var trimmed = raw.count > keepN ? Array(raw.prefix(keepN)) : raw
        if trimmed.count > fadeN {
            let start = trimmed.count - fadeN
            for i in 0..<fadeN {
                let t = Float(i) / Float(fadeN)
                trimmed[start + i] *= (1.0 - t)
            }
        }
        return trimmed
    }

    private func loadSample(named name: String) -> [Float]? {
        guard let path = ChamaRepiquePlugin.resourceBundle.path(forResource: name, ofType: "wav") else {
            ChamaRepiqueLog.log("Playback", "Sample \(name).wav not found")
            return nil
        }
        guard let data = try? Data(contentsOf: URL(fileURLWithPath: path)) else {
            ChamaRepiqueLog.log("Playback", "Failed to read \(name).wav")
            return nil
        }
        let pcm = decodeWav(Array(data))
        ChamaRepiqueLog.log("Playback", "  \(name).wav: \(pcm.count) samples (\(Int(Double(pcm.count) / Double(Self.sampleRate) * 1000))ms)")
        return pcm
    }

    /// Pre-render a response WAV (called at acceptance time).
    /// `bpm` (acceptedBpm) é passado a `canonRespostaBpm` como userBpm.
    /// `variant` selecciona resposta_audio_<variant> se definido no yaml
    /// (default "long"; relevante para chamadas com WAV pré-renderizado).
    /// Quando o yaml define `resposta_audio_<variant>` ou `resposta_audio`,
    /// o WAV está no bundle e não precisa de pre-render — skip.
    func preRender(chamada: String, bpm: Double, variant: String = "long") {
        // Se há WAV pré-renderizado no bundle, skip pre-render (toca direct).
        if CanonicalLibrary.shared.respostaAudioName(chamada, variant: variant) != nil {
            preRenderedChamada = nil
            preRenderedPath = nil
            return
        }
        guard let resolved = CanonicalLibrary.shared.resolveResposta(chamada),
              !regularSamples.isEmpty, !endingSamples.isEmpty,
              let tempDir = tempDir else { return }

        let canonBpm = CanonicalLibrary.shared.canonRespostaBpm(chamada, userBpm: bpm)
        guard let wav = renderPattern(resolved.pattern,
                                      resolution: resolved.resolution,
                                      bpm: canonBpm) else { return }

        let path = "\(tempDir)/resposta_pre_\(chamada).wav"
        let url = URL(fileURLWithPath: path)
        try? Data(wav).write(to: url)
        preRenderedChamada = chamada
        preRenderedPath = path
        ChamaRepiqueLog.log("Playback", "Pre-rendered \(chamada) (canonBpm=\(Int(canonBpm)), res=\(resolved.resolution))")
    }

    func clearPreRender() {
        preRenderedChamada = nil
        preRenderedPath = nil
    }

    /// Play the response for a detected chamada.
    /// `bpm` (acceptedBpm) é passado a `canonRespostaBpm` como userBpm.
    /// `variant` selecciona resposta_audio_<variant> se definido no yaml.
    /// Prioridade:
    /// 1. WAV pré-renderizado no bundle (yaml `resposta_audio_<variant>` ou
    ///    `resposta_audio`) — toca o ficheiro directamente.
    /// 2. Pattern render via samples + rotação queue + surdo layer.
    func playResposta(chamada: String, bpm: Double?, variant: String = "long") -> Bool {
        // 1. WAV pré-renderizado no bundle?
        if let wavName = CanonicalLibrary.shared.respostaAudioName(chamada, variant: variant) {
            guard let bundlePath = ChamaRepiquePlugin.resourceBundle.path(forResource: wavName, ofType: "wav") else {
                ChamaRepiqueLog.log("Playback", "Pre-rendered WAV not in bundle: \(wavName).wav")
                return false
            }
            ChamaRepiqueLog.log("Playback", "Playing \(chamada) (bundle WAV: \(wavName).wav, variant=\(variant))")
            clearPreRender()
            do {
                player = try AVAudioPlayer(contentsOf: URL(fileURLWithPath: bundlePath))
                player?.play()
                return true
            } catch {
                ChamaRepiqueLog.log("Playback", "Error playing bundle WAV: \(error)")
                return false
            }
        }

        // 2. Pattern render
        guard let resolved = CanonicalLibrary.shared.resolveResposta(chamada),
              !regularSamples.isEmpty, !endingSamples.isEmpty else {
            ChamaRepiqueLog.log("Playback", "No canon resposta for \(chamada) or samples not loaded")
            return false
        }
        let canonBpm = CanonicalLibrary.shared.canonRespostaBpm(chamada, userBpm: bpm)

        let path: String
        if preRenderedChamada == chamada, let prePath = preRenderedPath {
            path = prePath
            ChamaRepiqueLog.log("Playback", "Using pre-rendered \(chamada)")
        } else {
            guard let wav = renderPattern(resolved.pattern,
                                          resolution: resolved.resolution,
                                          bpm: canonBpm),
                  let tempDir = tempDir else { return false }

            path = "\(tempDir)/resposta_\(chamada).wav"
            let url = URL(fileURLWithPath: path)
            try? Data(wav).write(to: url)
        }
        clearPreRender()

        ChamaRepiqueLog.log("Playback", "Playing \(chamada) (canonBpm=\(Int(canonBpm)), res=\(resolved.resolution))")

        do {
            player = try AVAudioPlayer(contentsOf: URL(fileURLWithPath: path))
            player?.play()
            return true
        } catch {
            ChamaRepiqueLog.log("Playback", "Error: \(error)")
            return false
        }
    }

    func stop() {
        player?.stop()
        player = nil
    }

    func dispose() {
        stop()
    }

    // MARK: - Rendering

    /// Renderiza um pattern TUBS (`X`/`x`/`.`) para PCM WAV.
    private func renderPattern(_ pattern: String, resolution: Int, bpm: Double) -> [UInt8]? {
        let slots = pattern.compactMap { c -> Character? in
            (c == "X" || c == "x" || c == ".") ? c : nil
        }
        guard !slots.isEmpty else { return nil }

        // Identificar último onset (sempre ending por fallback)
        var lastOnsetSlot: Int = -1
        for (idx, c) in slots.enumerated() where c == "X" || c == "x" {
            lastOnsetSlot = idx
        }
        guard lastOnsetSlot >= 0 else { return nil }

        let stepS = CanonicalLibrary.slotSeconds(resolution: resolution, bpm: bpm)
        let maxSampleLen = max(
            regularSamples.map(\.count).max() ?? 0,
            endingSamples.map(\.count).max() ?? 0,
            surdoSample.count
        )
        let totalSamples = Int(Double(slots.count) * stepS * Double(Self.sampleRate)) + maxSampleLen
        var audio = [Float](repeating: 0, count: totalSamples)

        // Reset rotação no início de cada render (cada resposta tem a sua sequência)
        recentRegular.removeAll(keepingCapacity: true)

        let surdoGain = Float(pow(10.0, Double(Self.surdoGainDb) / 20.0))

        for (slotIdx, c) in slots.enumerated() where c == "X" || c == "x" {
            let isEnding = (c == "x") || (slotIdx == lastOnsetSlot)
            let sample = isEnding ? pickEnding() : pickRegular()
            // Volume
            let dbOffset: Double = isEnding ? Double.random(in: 0...2) : Double.random(in: -2...2)
            let gain = Float(pow(10.0, dbOffset / 20.0))
            let basePos = Int(round(Double(slotIdx) * stepS * Double(Self.sampleRate)))
            let n = min(sample.count, totalSamples - basePos)
            for j in 0..<n {
                audio[basePos + j] += sample[j] * gain
            }

            // Surdo layer: só em hits regulares (encorpa). Endings ficam limpos.
            if !isEnding && !surdoSample.isEmpty {
                let m = min(surdoSample.count, totalSamples - basePos)
                for j in 0..<m {
                    audio[basePos + j] += surdoSample[j] * surdoGain
                }
            }
        }

        // Peak limit: respostas densas + surdo layer podem clipar; atenua se peak > 0.95.
        var peak: Float = 0
        for v in audio { let a = abs(v); if a > peak { peak = a } }
        if peak > 0.95 {
            let scale = 0.95 / peak
            for i in 0..<audio.count { audio[i] *= scale }
        }

        return encodeWav(audio)
    }

    /// Pick from regular pool excluindo os últimos 2 picks (queue de rotação).
    private func pickRegular() -> [Float] {
        let n = regularSamples.count
        var candidates: [Int] = []
        for i in 0..<n where !recentRegular.contains(i) {
            candidates.append(i)
        }
        if candidates.isEmpty { candidates = Array(0..<n) }
        let idx = candidates.randomElement() ?? 0
        recentRegular.append(idx)
        if recentRegular.count > 2 { recentRegular.removeFirst() }
        return regularSamples[idx]
    }

    private func pickEnding() -> [Float] {
        endingSamples.randomElement() ?? endingSamples[0]
    }

    // MARK: - WAV codec

    private func decodeWav(_ wavBytes: [UInt8]) -> [Float] {
        var offset = 12
        while offset + 8 < wavBytes.count {
            let chunkId = String(bytes: wavBytes[offset..<offset+4], encoding: .ascii) ?? ""
            let chunkSize = Int(wavBytes[offset+4]) |
                           (Int(wavBytes[offset+5]) << 8) |
                           (Int(wavBytes[offset+6]) << 16) |
                           (Int(wavBytes[offset+7]) << 24)
            if chunkId == "data" {
                offset += 8
                let nSamples = chunkSize / 2
                var floats = [Float](repeating: 0, count: nSamples)
                for i in 0..<nSamples {
                    let lo = UInt16(wavBytes[offset + i * 2])
                    let hi = UInt16(wavBytes[offset + i * 2 + 1])
                    let unsigned: UInt16 = lo | (hi << 8)
                    let signed = Int16(bitPattern: unsigned)
                    floats[i] = Float(signed) / 32768.0
                }
                return floats
            }
            offset += 8 + chunkSize
            if chunkSize % 2 != 0 { offset += 1 }
        }
        return []
    }

    private func encodeWav(_ samples: [Float]) -> [UInt8] {
        let nSamples = samples.count
        let dataSize = nSamples * 2
        let fileSize = 44 + dataSize
        var buf = [UInt8](repeating: 0, count: fileSize)

        // RIFF header
        buf[0] = 0x52; buf[1] = 0x49; buf[2] = 0x46; buf[3] = 0x46
        writeUInt32(&buf, offset: 4, value: UInt32(fileSize - 8))
        buf[8] = 0x57; buf[9] = 0x41; buf[10] = 0x56; buf[11] = 0x45

        // fmt chunk
        buf[12] = 0x66; buf[13] = 0x6D; buf[14] = 0x74; buf[15] = 0x20
        writeUInt32(&buf, offset: 16, value: 16)
        writeUInt16(&buf, offset: 20, value: 1)
        writeUInt16(&buf, offset: 22, value: 1)
        writeUInt32(&buf, offset: 24, value: UInt32(Self.sampleRate))
        writeUInt32(&buf, offset: 28, value: UInt32(Self.sampleRate * 2))
        writeUInt16(&buf, offset: 32, value: 2)
        writeUInt16(&buf, offset: 34, value: 16)

        // data chunk
        buf[36] = 0x64; buf[37] = 0x61; buf[38] = 0x74; buf[39] = 0x61
        writeUInt32(&buf, offset: 40, value: UInt32(dataSize))

        for i in 0..<nSamples {
            let val = Int16(clamping: Int(samples[i] * 32767))
            buf[44 + i * 2] = UInt8(val & 0xFF)
            buf[44 + i * 2 + 1] = UInt8((val >> 8) & 0xFF)
        }

        return buf
    }

    private func writeUInt32(_ buf: inout [UInt8], offset: Int, value: UInt32) {
        buf[offset] = UInt8(value & 0xFF)
        buf[offset + 1] = UInt8((value >> 8) & 0xFF)
        buf[offset + 2] = UInt8((value >> 16) & 0xFF)
        buf[offset + 3] = UInt8((value >> 24) & 0xFF)
    }

    private func writeUInt16(_ buf: inout [UInt8], offset: Int, value: UInt16) {
        buf[offset] = UInt8(value & 0xFF)
        buf[offset + 1] = UInt8((value >> 8) & 0xFF)
    }
}
