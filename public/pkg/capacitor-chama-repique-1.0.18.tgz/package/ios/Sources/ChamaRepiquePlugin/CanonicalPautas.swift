import Foundation

/// Canonical 10-class names. Order MUST match phase1_classifier.tflite softmax outputs.
/// Source: data/experiment-results/production/results.json — classes are stored
/// in alphabetical (lexicographic) order, so chamada-10 sits at index 1, not 9.
let classNames = [
    "chamada-1", "chamada-10", "chamada-2", "chamada-3", "chamada-4",
    "chamada-5", "chamada-6", "chamada-7", "chamada-8", "chamada-9",
]

/// Empirical tunables ported from scripts/identify_chamada.py.
/// Source of truth: docs/chamada-evaluation-2026-04-27.md +
/// experiments/early-exit/early_exit_summary_prefix203.txt.
enum ChamadaConstants {
    // Pipeline cadence (matches Python identify_chamada.py)
    static let classifyIntervalS: Double = 0.15
    static let silenceGapS: Double = 0.4
    static let hardResetS: Double = 1.0
    static let minAudioS: Double = 0.5
    static let pollIntervalS: Double = 0.05
    static let sameN: Int = 3

    // BPM band (repenique in user's tuned setup)
    static let bpmMin: Double = 120
    static let bpmMax: Double = 145
    static let bpmFallback: Double = 130

    // Defaults for the global knobs (overridable via plugin config)
    static let defaultThreshold: Float = 0.70
    static let defaultHighConf: Float = 0.90
    static let defaultMargin: Float = 0.20
    static let defaultDensityThreshold: Double = 4.5

    // Default-excluded classes (chamada-2 confunde com chamada-1 e o cenário em palco
    // raramente usa só uma curta marcação isolada).
    static let defaultExcludedClasses: Set<String> = ["chamada-2"]

    /// Mínimo de áudio (s) antes de aceitar cada classe como candidata.
    /// Derivado da análise early-exit sobre o modelo de produção.
    /// Tuning 2026-05-06: c3 baixado de 1.0 → 0.85 para acelerar entrada da
    /// resposta. Discriminação vs c7/c9/c10 já é forte aos 0.85s; two-stage
    /// confirm cancela resposta se aceitação cedo divergir com mais buffer.
    static let tMinS: [String: Double] = [
        "chamada-1": 1.0,
        "chamada-2": 0.3,
        "chamada-3": 0.85,
        "chamada-4": 1.25,
        "chamada-5": 0.5,
        "chamada-6": 1.25,
        "chamada-7": 1.0,
        "chamada-8": 3.0,
        "chamada-9": 2.5,
        "chamada-10": 2.5,
    ]
    static let tMinDefault: Double = 1.5

    /// Threshold per-class para same3 (override do global).
    /// Tuning 2026-05-06+07: c5=0.55 (student 214 inflaciona conf c5 em
    /// ramp-up; FPs cross-class peak 0.46-0.53). c7=0.35 (peak típico
    /// 0.40-0.56; baixado de 0.40 para acelerar takes com ramp-up lento).
    static let tPerClass: [String: Float] = [
        "chamada-1": 0.50,
        "chamada-4": 0.40,
        "chamada-5": 0.55,
        "chamada-6": 0.40,
        "chamada-7": 0.35,
        "chamada-10": 0.65,
    ]

    /// High-conf shortcut: aceita à primeira frame se conf passar este nível.
    /// Tuning 2026-05-06+07: c3=0.70 (ramp-up lento; aos 0.70 top2 já ≤0.10
    /// e TUBS ≥0.91; two-stage confirm protege). c5=0.75 (peak real 0.86-0.92,
    /// FPs cross-class peak 0.66-0.74; 0.75 separa cleanly). c6=0.50 (peak
    /// típico 0.40-0.51; baixado de 0.70 que nunca era atingido — TUBS score
    /// já 0.91-1.00 desde 1.25s, sinal multi-feature).
    static let highConfPerClass: [String: Float] = [
        "chamada-1": 0.65,
        "chamada-3": 0.70,
        "chamada-4": 0.75,
        "chamada-5": 0.75,
        "chamada-6": 0.50,
        "chamada-7": 0.55,
        "chamada-10": 0.80,
    ]

    /// Quarter-note beats esperados por chamada (para speculative scheduling).
    /// expected_duration = expectedBeats[cls] * 60 / bpm.
    static let expectedBeats: [String: Double] = [
        "chamada-1": 4.98,
        "chamada-2": 5.11,
        "chamada-3": 3.91,
        "chamada-4": 9.87,
        "chamada-5": 5.51,
        "chamada-6": 5.39,
        "chamada-7": 5.37,
        "chamada-8": 16.27,
        "chamada-9": 9.37,
        "chamada-10": 6.50,
    ]

    /// Override do lead-in da resposta em BEATS (escala com BPM detectado).
    /// 1 beat = semínima = 8 fusas. Em 2/4: 2 beats por bar.
    /// Migração 2026-05-06: substituiu RESPOSTA_LEAD_OVERRIDE_S (segundos
    /// absolutos) que só funcionava a 1 BPM. Ajustado por escuta 2026-05-07.
    /// Classes não listadas usam o canon library.json directo.
    static let respostaLeadOverrideBeats: [String: Double] = [
        "chamada-4": 7,        // 3.5 bars (3 bars hit + meio bar respiração)
        "chamada-7": 3.25,     // ~1.5s @130bpm; canon yaml 4 beats parecia tarde
        "chamada-8": 15.5,     // half-beat antes do canon yaml 16; afinado por escuta 2026-05-07
        "chamada-9": 7.5,      // canon yaml era 8 beats (hit_repetido); puxa ½ beat
    ]

    /// Override empírico em segundos absolutos (legacy, frágil — não escala
    /// com BPM). Mantido vazio para back-compat; usar respostaLeadOverrideBeats.
    static let respostaLeadOverrideS: [String: Double] = [:]

    /// Per-class pre-fire: subtrai ao expectedEndTime para compensar latência
    /// interna do pipeline (extract spec + predict + tubs + render setup,
    /// ~155ms estimado). A resposta passa a TOCAR no instante canónico em
    /// vez de tarde. Não afecta T_MIN nem thresholds de aceitação — só o
    /// instante do fire após a chamada já ter sido aceite.
    static let respostaPrefireS: [String: Double] = [
        "chamada-3": 0.15,
        "chamada-6": 0.15,    // mesmo que c3 (~135ms pipeline)
        "chamada-8": 0.30,    // buffer ~6s torna extract+predict mais lento
        "chamada-9": 0.15,    // pipeline ~125ms (buffer ~3.5s)
    ]

    /// Mediana empírica do tempo até o classifier aceitar (audio_duration ao
    /// `accept`), por classe. Sessão 2026-05-07 (5 takes/classe, 45/45 OK).
    /// Usado pelo cap de outputLatencyS para garantir que a antecipação não
    /// reduz o buffer disponível para discriminação cross-class.
    static let acceptTTypicalS: [String: Double] = [
        "chamada-1": 1.37,
        "chamada-3": 1.44,
        "chamada-4": 2.76,
        "chamada-5": 0.97,
        "chamada-6": 1.51,
        "chamada-7": 1.16,
        "chamada-8": 5.71,
        "chamada-9": 3.09,
        "chamada-10": 2.74,
    ]
    static let acceptTDefaultS: Double = 1.5

    /// Gap mínimo entre fire e (last_x do hit OU acc_t típico) para que a
    /// resposta não toque com o user e o classifier tenha buffer informativo
    /// para o re-classify do two-stage confirm.
    static let outputLatencySafetyS: Double = 0.10

    /// Classes onde o TUBS bypass score-based pode dar override ao softmax.
    static let tubsBypassClasses: Set<String> = ["chamada-1", "chamada-3", "chamada-4", "chamada-10"]
    static let tubsBypassThreshold: Float = 0.70
    /// Tuning 2026-05-06: c3=0.45 (TUBS score atinge 0.97 ~1.07s mas attention
    /// só passa 0.50 ~1.58s; combinado com TUBS ≥0.70 e two-stage confirm).
    /// c4=0.20 floor evita bypass ruidoso quando user toca c10 incompleta
    /// (confs típicas c4 real 0.22-0.31).
    static let tubsBypassMinConf: [String: Float] = [
        "chamada-3": 0.45,
        "chamada-4": 0.20,
    ]
}

/// Threshold same3 efectivo para uma classe.
func sameThresholdFor(_ chamada: String, fallback: Float = ChamadaConstants.defaultThreshold) -> Float {
    ChamadaConstants.tPerClass[chamada] ?? fallback
}

/// High-conf shortcut threshold para uma classe.
func highConfFor(_ chamada: String, fallback: Float = ChamadaConstants.defaultHighConf) -> Float {
    ChamadaConstants.highConfPerClass[chamada] ?? fallback
}

/// Mínimo de áudio (s) para aceitar candidata.
func tMinFor(_ chamada: String) -> Double {
    ChamadaConstants.tMinS[chamada] ?? ChamadaConstants.tMinDefault
}

/// Duração esperada da chamada (s) ao BPM dado.
func expectedDurationSeconds(_ chamada: String, bpm: Double) -> Double? {
    guard let beats = ChamadaConstants.expectedBeats[chamada] else { return nil }
    return beats * 60.0 / bpm
}
