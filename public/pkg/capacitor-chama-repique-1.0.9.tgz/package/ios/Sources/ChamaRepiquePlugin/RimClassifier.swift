import Foundation
import TensorFlowLiteC

/// Binary rim/hit classifier — wrap de `rim_classifier.tflite`.
///
/// Input: 100ms @ 44100Hz (4410 samples) → mel-spec via `repenique_classifier_mel_spec`
/// (shape 64×10 = 640 floats) → TFLite → 1 logit. Sigmoid → P(rim).
final class RimClassifier {
    private var interpreter: OpaquePointer?
    private var model: OpaquePointer?
    private var classifierState: OpaquePointer?

    /// Threshold para classificar como R (vs X). Ajustável.
    var threshold: Float = 0.5

    func load() -> Bool {
        classifierState = repenique_classifier_init()
        guard classifierState != nil else {
            print("[RimClf] classifier_init failed")
            return false
        }
        guard let path = ChamaRepiquePlugin.resourceBundle.path(forResource: "rim_classifier", ofType: "tflite") else {
            print("[RimClf] model not found")
            return false
        }
        model = TfLiteModelCreateFromFile(path)
        let opts = TfLiteInterpreterOptionsCreate()
        TfLiteInterpreterOptionsSetNumThreads(opts, 1)
        interpreter = TfLiteInterpreterCreate(model, opts)
        TfLiteInterpreterOptionsDelete(opts)
        guard interpreter != nil,
              TfLiteInterpreterAllocateTensors(interpreter) == kTfLiteOk else {
            print("[RimClf] interpreter init failed")
            return false
        }
        return true
    }

    /// Classifica um chunk de 100ms (4410 samples). Retorna "X" ou "R".
    /// Se chunk for inválido ou inferência falhar, retorna "X" (fail-open).
    func classify(_ chunk: [Float]) -> String {
        guard let st = classifierState, let interp = interpreter else { return "X" }
        // Pad/truncate para WIN_SAMPLES (4410)
        let target = Int(REPENIQUE_CLF_WIN_SAMPLES)
        var input = [Float](repeating: 0, count: target)
        let n = min(chunk.count, target)
        for i in 0..<n { input[i] = chunk[i] }

        var mel = [Float](repeating: 0, count: Int(REPENIQUE_CLF_OUT_SIZE))
        let rc = input.withUnsafeBufferPointer { audioPtr in
            mel.withUnsafeMutableBufferPointer { melPtr in
                repenique_classifier_mel_spec(st, audioPtr.baseAddress!, melPtr.baseAddress!)
            }
        }
        guard rc == 0 else { return "X" }

        let inT = TfLiteInterpreterGetInputTensor(interp, 0)
        mel.withUnsafeBufferPointer { ptr in
            TfLiteTensorCopyFromBuffer(inT, ptr.baseAddress!, ptr.count * MemoryLayout<Float>.size)
        }
        guard TfLiteInterpreterInvoke(interp) == kTfLiteOk else { return "X" }

        let outT = TfLiteInterpreterGetOutputTensor(interp, 0)
        var logit: [Float] = [0]
        logit.withUnsafeMutableBufferPointer { ptr in
            TfLiteTensorCopyToBuffer(outT, ptr.baseAddress!, ptr.count * MemoryLayout<Float>.size)
        }
        let prob = 1.0 / (1.0 + expf(-logit[0]))
        return prob >= threshold ? "R" : "X"
    }

    func dispose() {
        if let interpreter = interpreter { TfLiteInterpreterDelete(interpreter) }
        if let model = model { TfLiteModelDelete(model) }
        if let st = classifierState { repenique_classifier_free(st) }
        interpreter = nil
        model = nil
        classifierState = nil
    }
}
