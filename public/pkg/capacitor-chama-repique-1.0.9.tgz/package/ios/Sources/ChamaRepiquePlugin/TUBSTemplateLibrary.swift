import Foundation

/// Loader de templates TUBS (canon da `library.json` + user templates JSON
/// dentro de `Assets/data/`). Fornece scoring vs templates para o bypass
/// no `ChamadaClassifier`.
final class TUBSTemplateLibrary {
    static let shared = TUBSTemplateLibrary()

    /// Canon hit string (sem `|`) por chamada. Vem de `library.json[c].hit`.
    let canons: [String: String]

    /// User templates por chamada. Cada string já sem `|`.
    /// Source: `Assets/data/user_templates_chamada-{1,3,4,10}.json`.
    let userTemplates: [String: [String]]

    private init() {
        // 1) Canons da library
        var canons: [String: String] = [:]
        for (name, info) in CanonicalLibrary.shared.chamadas {
            let hit = info.hit.replacingOccurrences(of: "|", with: "")
            if !hit.isEmpty {
                canons[name] = hit
            }
        }
        self.canons = canons

        // 2) User templates por classe (se ficheiro existir no bundle)
        var templates: [String: [String]] = [:]
        for cls in classNames {
            guard let url = ChamaRepiquePlugin.resourceBundle.url(forResource: "user_templates_\(cls)", withExtension: "json") else {
                continue
            }
            do {
                let data = try Data(contentsOf: url)
                guard let json = try JSONSerialization.jsonObject(with: data) as? [String: Any],
                      let arr = json["templates"] as? [[String: Any]] else {
                    continue
                }
                let strings = arr.compactMap { ($0["tubs"] as? String)?.replacingOccurrences(of: "|", with: "") }
                if !strings.isEmpty {
                    templates[cls] = strings
                    print("[TUBSTemplates] \(cls): \(strings.count) templates")
                }
            } catch {
                print("[TUBSTemplates] failed to load \(cls): \(error)")
            }
        }
        self.userTemplates = templates
    }

    /// Score = max(score vs canon, max(score vs user templates))
    /// (mirror de `_score_class_tubs` em identify_chamada.py).
    func scoreClass(pred: String, chamada: String) -> Double {
        var best: Double = 0
        if let canon = canons[chamada], !canon.isEmpty {
            best = TUBSScorer.score(pred: pred, canon: canon)
        }
        if let arr = userTemplates[chamada] {
            for tpl in arr {
                let s = TUBSScorer.score(pred: pred, canon: tpl)
                if s > best { best = s }
            }
        }
        return best
    }
}

/// Stateless scoring: 0.5 * slot_acc + 0.5 * F1 com tolerância ±1 slot.
/// Mirror exacto de `_score_tubs` em scripts/identify_chamada.py.
enum TUBSScorer {
    static func score(pred: String, canon: String, tolerance: Int = 1) -> Double {
        let n = min(pred.count, canon.count)
        guard n > 0 else { return 0 }

        let predArr = Array(pred)
        let canonArr = Array(canon)

        var slotMatches = 0
        var canonOnsets: [Int] = []
        var predOnsets: [Int] = []
        for i in 0..<n {
            if predArr[i] == canonArr[i] { slotMatches += 1 }
            if canonArr[i] == "X" { canonOnsets.append(i) }
            if predArr[i] == "X" { predOnsets.append(i) }
        }
        let slotAcc = Double(slotMatches) / Double(n)

        var used = Set<Int>()
        var tp = 0
        for c in canonOnsets {
            for p in predOnsets where !used.contains(p) {
                if abs(p - c) <= tolerance {
                    used.insert(p)
                    tp += 1
                    break
                }
            }
        }
        let fp = predOnsets.count - used.count
        let fn = canonOnsets.count - tp
        let pr = (tp + fp) > 0 ? Double(tp) / Double(tp + fp) : 0
        let rc = (tp + fn) > 0 ? Double(tp) / Double(tp + fn) : 0
        let f1 = (pr + rc) > 0 ? 2 * pr * rc / (pr + rc) : 0
        return 0.5 * slotAcc + 0.5 * f1
    }
}
