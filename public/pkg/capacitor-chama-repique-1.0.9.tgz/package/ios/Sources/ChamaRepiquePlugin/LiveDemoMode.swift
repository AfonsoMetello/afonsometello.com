import Foundation
import AVFoundation

/// Live "improviso" mode (Phase 2) — port simplificado de `scripts/live_demo.py`
/// (echo mode). Loop infinito: count-in → user toca chamada (N bars) → app
/// extrai TUBS via `TUBSExtractor` → toca resposta (echo do hit pattern).
///
/// Diferenças vs Mac Python:
/// - Sem ring buffer gapless. Cycles são sequenciais (record → play). Gap
///   pequeno entre fim do record e início do play (~tens of ms). Para v1
///   é aceitável; v2 pode usar AVAudioSourceNode para gapless.
/// - Sem CNN onset detector. Usa `TUBSExtractor` (native onset envelope +
///   peak picker). Onsets ligeiramente mais ruidosos que CNN mas funcionais.
/// - Sem LLM. Echo only — resposta = hit pattern (X→P). LLM fica para
///   depois (precisa MLX-Swift integration ou backend remoto).
final class LiveDemoMode {
    // ------------------------------------------------------------------
    // Config
    // ------------------------------------------------------------------
    var bpm: Double = 130
    var barsChamada: Int = 2
    var barsResposta: Int = 2
    var anticipateMs: Double = 30
    var classifyVoices: Bool = false
    var detectRim: Bool = false

    // ------------------------------------------------------------------
    // Constants
    // ------------------------------------------------------------------
    private static let beatsPerBar = 2
    private static let fusasPerBar = 16
    private static let resolution = 32
    private static let sampleRate = 44100

    // ------------------------------------------------------------------
    // Native + state
    // ------------------------------------------------------------------
    private var dspState: OpaquePointer?
    private var voiceClassifier: VoiceClassifier?
    private var rimClassifier: RimClassifier?
    /// CNN onset detector (paridade Python live_demo --onset-engine cnn).
    /// Carregado em load() e usado em TUBSExtractor.
    private let onsetCNN = OnsetCNN()

    private let renderQueue = DispatchQueue(label: "LiveDemo.render", qos: .userInitiated)
    private var running = false
    private var phase: Phase = .idle
    private var cycleIndex = 0

    // Mic audio capture (chamada window)
    private var capturedAudio: [Float] = []
    private var captureLock = NSLock()
    private var captureWindowSamples = 0

    // Output player
    private var player: AVAudioPlayer?
    private var tempDir: String

    // Pre-rendered count-in (sine 1500Hz × 4 beats)
    private var countInWav: [UInt8]?

    // Beep para resposta (reusa beat samples do PlaybackEngine via render)
    private var beep: [Float] = []

    private enum Phase {
        case idle
        case countIn
        case chamada
        case resposta
    }

    // ------------------------------------------------------------------
    // Callbacks (UI events)
    // ------------------------------------------------------------------
    var onCycleStart: ((_ index: Int) -> Void)?
    var onChamadaTubs: ((_ tubs: String, _ nOnsets: Int) -> Void)?
    var onRespostaTubs: ((_ tubs: String) -> Void)?
    var onLog: ((String) -> Void)?

    // ------------------------------------------------------------------
    // Init / load
    // ------------------------------------------------------------------
    init() {
        tempDir = NSTemporaryDirectory()
    }

    func load() -> Bool {
        dspState = repenique_init()
        guard dspState != nil else {
            print("[LiveDemo] repenique_init failed")
            return false
        }
        // Best-effort: TUBSExtractor cai para peak picker se este falhar.
        if !onsetCNN.load() {
            print("[LiveDemo] OnsetCNN load failed — fallback para envelope peak picker")
        }
        prerenderCountIn()
        prerenderBeep()
        return true
    }

    func dispose() {
        stop()
        if let dspState = dspState { repenique_free(dspState) }
        dspState = nil
        voiceClassifier?.dispose()
        rimClassifier?.dispose()
        onsetCNN.dispose()
    }

    // ------------------------------------------------------------------
    // Lifecycle
    // ------------------------------------------------------------------
    /// Inicia o loop. Caller é responsável por chamar `addSamples` com chunks
    /// do mic enquanto a phase = .chamada (gerido externamente pelo plugin).
    func start() {
        guard !running else { return }
        running = true
        cycleIndex = 0
        if classifyVoices { voiceClassifier = VoiceClassifier(); _ = voiceClassifier?.load() }
        if detectRim, voiceClassifier == nil {
            rimClassifier = RimClassifier(); _ = rimClassifier?.load()
        }
        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            self?.runLoop()
        }
    }

    func stop() {
        running = false
        phase = .idle
        player?.stop()
        player = nil
    }

    /// Chamado pelo plugin com chunks do mic. Apenas acumula durante phase=.chamada.
    func addSamples(_ samples: [Float]) {
        guard phase == .chamada else { return }
        captureLock.lock()
        capturedAudio.append(contentsOf: samples)
        if capturedAudio.count > captureWindowSamples {
            capturedAudio.removeFirst(capturedAudio.count - captureWindowSamples)
        }
        captureLock.unlock()
    }

    // ------------------------------------------------------------------
    // Main loop (corre numa background queue)
    // ------------------------------------------------------------------
    private func runLoop() {
        let beatDur = 60.0 / bpm
        let barDur = beatDur * Double(Self.beatsPerBar)
        let chamadaDur = barDur * Double(barsChamada)

        // Count-in (uma vez)
        playCountIn()
        let countInDur = beatDur * 4.0
        sleepS(countInDur)

        while running {
            cycleIndex += 1
            onCycleStart?(cycleIndex)

            // Phase: chamada — captura mic durante chamadaDur
            phase = .chamada
            captureLock.lock()
            capturedAudio.removeAll(keepingCapacity: true)
            captureWindowSamples = Int(chamadaDur * 1.2 * Double(Self.sampleRate))
            captureLock.unlock()

            sleepS(chamadaDur)

            // Phase: process
            phase = .resposta
            captureLock.lock()
            let audio = capturedAudio
            captureLock.unlock()

            guard let dspState = dspState,
                  let result = TUBSExtractor.extract(audio: audio, dspState: dspState,
                                                     bpmHint: bpm,
                                                     onsetCNN: onsetCNN) else {
                onLog?("[LiveDemo] TUBS extract failed")
                continue
            }

            let hitFull = padOrTruncateTubs(result.tubs, bars: barsChamada)
            onChamadaTubs?(hitFull, result.nOnsets)

            // Echo: resposta = hit (X→P→render como X)
            let respostaPattern = hitFull.replacingOccurrences(of: "|", with: "")
            onRespostaTubs?("|" + chunked(respostaPattern, size: Self.fusasPerBar).joined(separator: "|") + "|")

            // Phase: resposta — render + play
            playRespostaPattern(respostaPattern, bars: barsResposta)
            let respostaDur = barDur * Double(barsResposta)
            sleepS(respostaDur)
        }

        phase = .idle
    }

    // ------------------------------------------------------------------
    // Helpers
    // ------------------------------------------------------------------
    private func sleepS(_ seconds: Double) {
        guard running else { return }
        Thread.sleep(forTimeInterval: max(0, seconds))
    }

    private func padOrTruncateTubs(_ tubs: String, bars: Int) -> String {
        let stripped = tubs.replacingOccurrences(of: "|", with: "")
        let target = bars * Self.fusasPerBar
        var s = stripped
        if s.count < target {
            s += String(repeating: ".", count: target - s.count)
        } else if s.count > target {
            s = String(s.prefix(target))
        }
        return "|" + chunked(s, size: Self.fusasPerBar).joined(separator: "|") + "|"
    }

    private func chunked(_ s: String, size: Int) -> [String] {
        var out: [String] = []
        var i = s.startIndex
        while i < s.endIndex {
            let j = s.index(i, offsetBy: size, limitedBy: s.endIndex) ?? s.endIndex
            out.append(String(s[i..<j]))
            i = j
        }
        return out
    }

    // ------------------------------------------------------------------
    // Audio synthesis: count-in + resposta beep render
    // ------------------------------------------------------------------
    private func prerenderCountIn() {
        let sr = Self.sampleRate
        let beatDur = 60.0 / bpm
        let totalSamples = Int(beatDur * 4.0 * Double(sr))
        var audio = [Float](repeating: 0, count: totalSamples)

        // 4 entry beeps em positions 0, beat, 2*beat, 3*beat
        let entryBeep = synthesizeEntryBeep()
        for i in 0..<4 {
            let pos = Int(Double(i) * beatDur * Double(sr))
            for j in 0..<entryBeep.count where pos + j < totalSamples {
                audio[pos + j] += entryBeep[j]
            }
        }
        countInWav = encodeWav(audio, sampleRate: sr)
    }

    private func prerenderBeep() {
        // Beep grave (~107Hz) com decay rápido — simula hit do repenique.
        let sr = Self.sampleRate
        let durS = 0.08
        let n = Int(durS * Double(sr))
        beep = (0..<n).map { i in
            let t = Double(i) / Double(sr)
            return Float(0.5 * sin(2 * .pi * 107.0 * t) * exp(-15 * t))
        }
    }

    private func synthesizeEntryBeep() -> [Float] {
        let sr = Self.sampleRate
        let durS = 0.08
        let n = Int(durS * Double(sr))
        return (0..<n).map { i in
            let t = Double(i) / Double(sr)
            return Float(0.4 * sin(2 * .pi * 1500.0 * t) * exp(-15 * t))
        }
    }

    private func playCountIn() {
        guard let wav = countInWav else { return }
        let path = "\(tempDir)/livedemo_countin.wav"
        try? Data(wav).write(to: URL(fileURLWithPath: path))
        playWavPath(path)
    }

    private func playRespostaPattern(_ stripped: String, bars: Int) {
        let sr = Self.sampleRate
        let beatDur = 60.0 / bpm
        let barDur = beatDur * Double(Self.beatsPerBar)
        let fusaS = beatDur / 8.0  // 1 fusa = 1/8 da semínima
        let totalSamples = Int(barDur * Double(bars) * Double(sr)) + beep.count
        var audio = [Float](repeating: 0, count: totalSamples)

        let anticipateSamples = Int(anticipateMs / 1000.0 * Double(sr))

        let chars = Array(stripped)
        for (i, c) in chars.enumerated() where c == "X" || c == "P" {
            var pos = Int(Double(i) * fusaS * Double(sr)) - anticipateSamples
            if pos < 0 { pos = 0 }
            for j in 0..<beep.count where pos + j < totalSamples {
                audio[pos + j] += beep[j]
            }
        }

        let wav = encodeWav(audio, sampleRate: sr)
        let path = "\(tempDir)/livedemo_resposta.wav"
        try? Data(wav).write(to: URL(fileURLWithPath: path))
        playWavPath(path)
    }

    private func playWavPath(_ path: String) {
        do {
            player?.stop()
            player = try AVAudioPlayer(contentsOf: URL(fileURLWithPath: path))
            player?.play()
        } catch {
            print("[LiveDemo] playback error: \(error)")
        }
    }

    // ------------------------------------------------------------------
    // WAV encoding (matches PlaybackEngine encodeWav)
    // ------------------------------------------------------------------
    private func encodeWav(_ samples: [Float], sampleRate: Int) -> [UInt8] {
        let nSamples = samples.count
        let dataSize = nSamples * 2
        let fileSize = 44 + dataSize
        var buf = [UInt8](repeating: 0, count: fileSize)

        buf[0] = 0x52; buf[1] = 0x49; buf[2] = 0x46; buf[3] = 0x46
        writeUInt32(&buf, offset: 4, value: UInt32(fileSize - 8))
        buf[8] = 0x57; buf[9] = 0x41; buf[10] = 0x56; buf[11] = 0x45

        buf[12] = 0x66; buf[13] = 0x6D; buf[14] = 0x74; buf[15] = 0x20
        writeUInt32(&buf, offset: 16, value: 16)
        writeUInt16(&buf, offset: 20, value: 1)
        writeUInt16(&buf, offset: 22, value: 1)
        writeUInt32(&buf, offset: 24, value: UInt32(sampleRate))
        writeUInt32(&buf, offset: 28, value: UInt32(sampleRate * 2))
        writeUInt16(&buf, offset: 32, value: 2)
        writeUInt16(&buf, offset: 34, value: 16)

        buf[36] = 0x64; buf[37] = 0x61; buf[38] = 0x74; buf[39] = 0x61
        writeUInt32(&buf, offset: 40, value: UInt32(dataSize))

        for i in 0..<nSamples {
            let val = Int16(clamping: Int(samples[i] * 32767))
            buf[44 + i * 2] = UInt8(val & 0xFF)
            buf[44 + i * 2 + 1] = UInt8((val >> 8) & 0xFF)
        }
        return buf
    }

    private func writeUInt32(_ buf: inout [UInt8], offset: Int, value: UInt32) {
        buf[offset] = UInt8(value & 0xFF)
        buf[offset + 1] = UInt8((value >> 8) & 0xFF)
        buf[offset + 2] = UInt8((value >> 16) & 0xFF)
        buf[offset + 3] = UInt8((value >> 24) & 0xFF)
    }

    private func writeUInt16(_ buf: inout [UInt8], offset: Int, value: UInt16) {
        buf[offset] = UInt8(value & 0xFF)
        buf[offset + 1] = UInt8((value >> 8) & 0xFF)
    }
}
