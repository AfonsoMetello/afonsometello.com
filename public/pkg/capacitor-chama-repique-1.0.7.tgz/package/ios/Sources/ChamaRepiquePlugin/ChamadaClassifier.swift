import Foundation

/// Resultado final de uma chamada (após two-stage confirmation).
struct ClassificationResult {
    let label: String          // "chamada-1" .. "chamada-10" or "none"
    let candidate: String?     // a candidata aceite via same3/high-conf
    let confirmed: Bool        // candidate == final?
    let confidence: Float
    let probabilities: [Float] // probs originais (não masked) ordem `classNames`
    let bpm: Double?
    let durationS: Double
    let nReschedules: Int
}

/// Estado intermédio (frame de inferência) para diagnóstico/UI.
struct ClassificationFrame {
    let topClass: String
    let confidence: Float
    let probabilities: [Float]
    let audioDurationS: Double
    let masked: Bool           // true se algumas classes foram zeradas
    let densityHitsPerSec: Double?
}

/// Classificador incremental, full-port do `ChamadaIdentifier` em
/// `scripts/identify_chamada.py`. Phase A: pipeline core (T_MIN gating,
/// same3 per-class, high-conf shortcut, margin, density override,
/// two-stage confirmation, speculative scheduling, lead-in canónico).
/// TUBS bypass + score-based swap ficam para a Phase B.
final class ChamadaClassifier {
    // ------------------------------------------------------------------
    // Constants (mirrored from src/__init__.py)
    // ------------------------------------------------------------------
    private static let sampleRate = 44100
    private static let hopLength = 512
    private static let maxFrames = 736
    private static let maxBufferS: Double = Double(maxFrames * hopLength) / Double(sampleRate)
    private static let silenceThreshold: Float = 0.015
    private static let attMelSize = 128 * maxFrames

    private static let maxBufferSamples = Int(Double(sampleRate) * maxBufferS)
    private static let nClasses = classNames.count

    // ------------------------------------------------------------------
    // Tunables (overridable via plugin config)
    // ------------------------------------------------------------------
    var threshold: Float = ChamadaConstants.defaultThreshold       // global same3 threshold
    var highConfThreshold: Float = ChamadaConstants.defaultHighConf
    var margin: Float = ChamadaConstants.defaultMargin
    var densityThreshold: Double = ChamadaConstants.defaultDensityThreshold
    var excludedClasses: Set<String> = ChamadaConstants.defaultExcludedClasses
    var respostaEnabled: Bool = true   // se true, espera lead-in canónico antes de fire

    // ------------------------------------------------------------------
    // Native + TFLite handles
    // ------------------------------------------------------------------
    private var interpreter: OpaquePointer?
    private var model: OpaquePointer?
    private var dspState: OpaquePointer?
    private var classifierState: OpaquePointer?  // p/ density estimate (Phase 2 mel/peak)
    private let yamnet = YamnetFilter()
    var yamnetEnabled: Bool = false   // por defeito off (10-class model + masks já filtram)

    // ------------------------------------------------------------------
    // Audio buffer (lock-protected)
    // ------------------------------------------------------------------
    private var audioBuffer: [Float]
    private var bufferLen = 0
    private let bufferLock = NSLock()

    // ------------------------------------------------------------------
    // Pipeline state
    // ------------------------------------------------------------------
    private var running = false
    private var paused = false
    private var muted = false
    private var hasSound = false
    private var soundStartTime: TimeInterval?
    private var lastSoundTime: TimeInterval = 0
    private var lastClassifyTime: TimeInterval = 0
    private var yamnetChecked = false
    private var isPercussion = true

    private var recentPredictions: [(String, Float)] = []
    private var currentPrediction: String?
    private var currentConfidence: Float = 0
    private var currentProbs: [Float]?

    private var acceptedClass: String?
    private var acceptedBpm: Double?
    private var expectedEndTime: TimeInterval?
    private var nReschedules = 0
    private var lastDensity: Double = 0

    // TUBS state (Phase B bypass)
    private var lastTubsScores: [String: Double] = [:]
    private var lastAcceptViaBypass = false
    var tubsEnabled: Bool = true

    // Loop scheduling
    private let loopQueue = DispatchQueue(label: "ChamadaClassifier.loop", qos: .userInitiated)
    private let inferenceQueue = DispatchQueue(label: "ChamadaClassifier.inference", qos: .userInitiated)

    // ------------------------------------------------------------------
    // Callbacks
    // ------------------------------------------------------------------
    var onResult: ((ClassificationResult) -> Void)?
    var onFrame: ((ClassificationFrame) -> Void)?
    var onCandidate: ((_ chamada: String, _ bpm: Double, _ leadInS: Double) -> Void)?
    var onLog: ((String) -> Void)?

    private(set) var lastDebug = ""

    // ------------------------------------------------------------------
    // Init / load
    // ------------------------------------------------------------------
    init() {
        audioBuffer = [Float](repeating: 0, count: Self.maxBufferSamples)
    }

    func load() -> Bool {
        // C++ DSP (Phase 1)
        dspState = repenique_init()
        guard dspState != nil else {
            print("[Classifier] repenique_init() failed")
            return false
        }
        let version = String(cString: repenique_version())
        print("[Classifier] DSP version: \(version)")

        // C++ classifier helper (Phase 2: mel-spec + peak-pick para density)
        classifierState = repenique_classifier_init()
        if classifierState == nil {
            print("[Classifier] repenique_classifier_init() failed (density override desactivado)")
        }

        // Attention model (10 classes)
        guard let modelPath = ChamaRepiquePlugin.resourceBundle.path(forResource: "chamada_attention_v1", ofType: "tflite") else {
            print("[Classifier] phase1 model not found")
            return false
        }
        model = TfLiteModelCreateFromFile(modelPath)
        guard model != nil else {
            print("[Classifier] Failed to create model")
            return false
        }

        let options = TfLiteInterpreterOptionsCreate()
        TfLiteInterpreterOptionsSetNumThreads(options, 2)
        interpreter = TfLiteInterpreterCreate(model, options)
        TfLiteInterpreterOptionsDelete(options)
        guard interpreter != nil else {
            print("[Classifier] Failed to create interpreter")
            return false
        }
        guard TfLiteInterpreterAllocateTensors(interpreter) == kTfLiteOk else {
            print("[Classifier] Failed to allocate tensors")
            return false
        }

        if yamnetEnabled, !yamnet.load() { return false }

        // Force CanonicalLibrary load (lazy singleton fires here)
        _ = CanonicalLibrary.shared

        print("[Classifier] All models loaded OK (\(Self.nClasses) classes)")
        return true
    }

    // ------------------------------------------------------------------
    // Lifecycle
    // ------------------------------------------------------------------
    func start() {
        running = true
        paused = false
        runLoop()
    }

    func stop() {
        running = false
        hardReset()
    }

    func setMuted(_ value: Bool) { muted = value }
    func resume() { paused = false }

    func dispose() {
        stop()
        if let interpreter = interpreter { TfLiteInterpreterDelete(interpreter) }
        if let model = model { TfLiteModelDelete(model) }
        if let dspState = dspState { repenique_free(dspState) }
        if let classifierState = classifierState { repenique_classifier_free(classifierState) }
        yamnet.dispose()
        interpreter = nil
        model = nil
        self.dspState = nil
        self.classifierState = nil
    }

    // ------------------------------------------------------------------
    // Audio ingress (chamado pelo AudioCaptureService, audio thread)
    // ------------------------------------------------------------------
    func addSamples(_ samples: [Float]) {
        guard running, !muted else { return }

        var sumSq: Float = 0
        for s in samples { sumSq += s * s }
        let rms = sqrtf(sumSq / Float(samples.count))
        let isSound = rms > Self.silenceThreshold
        let now = Date().timeIntervalSince1970

        bufferLock.lock()
        defer { bufferLock.unlock() }

        if isSound {
            if soundStartTime == nil {
                soundStartTime = now
            }
            appendSamplesLocked(samples)
            hasSound = true
            lastSoundTime = now
        } else if hasSound {
            // Mantém a tail para detectar gap de silêncio
            appendSamplesLocked(samples)
        }
    }

    // ------------------------------------------------------------------
    // Classify loop (re-armado a cada POLL_INTERVAL_S no loopQueue)
    // ------------------------------------------------------------------
    private func runLoop() {
        loopQueue.asyncAfter(deadline: .now() + ChamadaConstants.pollIntervalS) { [weak self] in
            self?.iterateLoop()
            if self?.running == true { self?.runLoop() }
        }
    }

    private func iterateLoop() {
        guard running, !paused else { return }

        bufferLock.lock()
        let bufLen = bufferLen
        let snapshotHasSound = hasSound
        let snapshotSoundStart = soundStartTime
        bufferLock.unlock()

        guard snapshotHasSound, bufLen > 0 else { return }

        let now = Date().timeIntervalSince1970
        let silenceMs = lastSoundTime > 0 ? (now - lastSoundTime) : 0
        let audioDurationS = Double(bufLen) / Double(Self.sampleRate)

        // 1) Silêncio após aceitação → fire
        if silenceMs >= ChamadaConstants.silenceGapS, acceptedClass != nil {
            fireResponse()
            return
        }

        // 2) Silêncio longo → hard reset
        if silenceMs >= ChamadaConstants.hardResetS {
            print("[Classifier] Hard reset — \(String(format: "%.2f", silenceMs))s silence")
            hardReset()
            return
        }

        // 3) Resposta agendada e expected_end atingido → fire
        if respostaEnabled,
           acceptedClass != nil,
           let endT = expectedEndTime,
           now >= endT {
            fireResponse()
            return
        }

        // 4) Cadência de classify
        if now - lastClassifyTime < ChamadaConstants.classifyIntervalS { return }
        if audioDurationS < ChamadaConstants.minAudioS { return }

        // Snapshot do buffer
        bufferLock.lock()
        let audio = Array(audioBuffer[0..<bufLen])
        bufferLock.unlock()

        // YAMNet uma vez (se enabled)
        if yamnetEnabled, !yamnetChecked {
            if audioDurationS >= 0.5 {
                let isPerc = yamnet.isPercussion(audio)
                yamnetChecked = true
                isPercussion = isPerc
                if !isPerc {
                    lastClassifyTime = now
                    return
                }
            } else {
                return
            }
        }

        lastClassifyTime = now

        // Inference síncrona (rápida o suficiente — ~25ms)
        guard let probs = runInference(audio) else { return }

        // TUBS extraction (one shot — usado para density + bypass scoring)
        var tubsResult: TUBSResult?
        if tubsEnabled, let dspState = dspState {
            tubsResult = TUBSExtractor.extract(audio: audio, dspState: dspState)
            if let r = tubsResult {
                for cls in ChamadaConstants.tubsBypassClasses {
                    lastTubsScores[cls] = TUBSTemplateLibrary.shared.scoreClass(pred: r.stripped, chamada: cls)
                }
            }
        }

        let density: Double
        if let r = tubsResult {
            density = Double(r.nOnsets) / max(0.1, r.durationS)
        } else {
            density = estimateDensity(audio: audio, durationS: audioDurationS)
        }
        lastDensity = density

        // Aplicar máscaras
        var masked = probs
        var maskedIdx: [Int] = []
        for i in 0..<Self.nClasses {
            let c = classNames[i]
            if excludedClasses.contains(c) {
                maskedIdx.append(i)
                continue
            }
            if audioDurationS < tMinFor(c) {
                maskedIdx.append(i)
            }
        }
        for i in maskedIdx { masked[i] = 0 }

        let maskedSum = masked.reduce(0, +)
        guard maskedSum > 0 else {
            // Todas mascaradas (audio ainda muito curto); skip frame.
            return
        }

        // Argmax na masked
        var topIdx = 0
        var topProb: Float = -.infinity
        for i in 0..<Self.nClasses where masked[i] > topProb {
            topProb = masked[i]
            topIdx = i
        }
        var topClass = classNames[topIdx]
        var topConfidence = probs[topIdx] // confiança = valor original (não masked)

        // Density override: top1 ∈ {chamada-9, chamada-10} + density alta
        // + chamada-4 in top-3 elegível → swap.
        if (topClass == "chamada-9" || topClass == "chamada-10"),
           density >= densityThreshold {
            // top-3 das classes elegíveis
            let sortedIdx = masked.enumerated()
                .filter { $0.element > 0 }
                .sorted { $0.element > $1.element }
                .map { $0.offset }
            let top3 = Array(sortedIdx.prefix(3)).map { classNames[$0] }
            if top3.contains("chamada-4"),
               let c4Idx = classNames.firstIndex(of: "chamada-4"),
               masked[c4Idx] > 0 {
                topIdx = c4Idx
                topClass = "chamada-4"
                topConfidence = probs[c4Idx]
            }
        }

        // Margin (top1 - top2) entre classes elegíveis (valores masked)
        let sortedMasked = masked.sorted(by: >)
        let top2 = sortedMasked.count > 1 ? sortedMasked[1] : 0
        let topMinusTop2 = topConfidence - top2

        // Density bypass do margin para chamada-4 dense
        var marginRequired = margin
        if topClass == "chamada-4", density >= densityThreshold {
            marginRequired = 0
        }
        let marginOk = topMinusTop2 >= marginRequired

        currentPrediction = topClass
        currentConfidence = topConfidence
        currentProbs = probs
        recentPredictions.append((topClass, topConfidence))
        if recentPredictions.count > ChamadaConstants.sameN * 2 {
            recentPredictions.removeFirst(recentPredictions.count - ChamadaConstants.sameN)
        }

        onFrame?(ClassificationFrame(
            topClass: topClass,
            confidence: topConfidence,
            probabilities: probs,
            audioDurationS: audioDurationS,
            masked: !maskedIdx.isEmpty,
            densityHitsPerSec: density
        ))

        let tMinTop = tMinFor(topClass)
        let hcTop = highConfFor(topClass, fallback: highConfThreshold)

        // Atalho high-confidence
        if topConfidence >= hcTop,
           audioDurationS >= tMinTop,
           marginOk,
           topClass != acceptedClass {
            acceptClass(topClass, audio: audio, durationS: audioDurationS,
                        soundStart: snapshotSoundStart, via: "high_conf")
            return
        }

        // Same3 fallback (com TUBS bypass para classes elegíveis)
        if recentPredictions.count >= ChamadaConstants.sameN {
            let lastN = Array(recentPredictions.suffix(ChamadaConstants.sameN))
            let sameClass = lastN.allSatisfy { $0.0 == lastN[0].0 }
            if sameClass {
                let cls = lastN[0].0
                let tForClass = sameThresholdFor(cls, fallback: threshold)
                let confident = lastN.allSatisfy { $0.1 >= tForClass }

                // TUBS bypass: 0 falsos positivos validados em ~240 samples
                // para >= 0.70. Para chamada-3 (conf típica alta) exigimos
                // também min_conf attention.
                let tubsScore = lastTubsScores[cls] ?? 0
                let bypassMinConf = ChamadaConstants.tubsBypassMinConf[cls] ?? 0
                let bypassConfOk = lastN.allSatisfy { $0.1 >= bypassMinConf }
                let tubsBypass = tubsEnabled
                    && ChamadaConstants.tubsBypassClasses.contains(cls)
                    && tubsScore >= Double(ChamadaConstants.tubsBypassThreshold)
                    && bypassConfOk

                if (confident || tubsBypass), marginOk {
                    let tMinCls = tMinFor(cls)
                    if audioDurationS >= tMinCls, cls != acceptedClass {
                        lastAcceptViaBypass = tubsBypass && !confident
                        let viaTag = lastAcceptViaBypass ? "tubs_bypass" : "same3"
                        if lastAcceptViaBypass {
                            print("[Classifier] tubs_bypass \(cls) score=\(String(format: "%.3f", tubsScore)) dur=\(String(format: "%.2f", audioDurationS))s")
                        }
                        acceptClass(cls, audio: audio, durationS: audioDurationS,
                                    soundStart: snapshotSoundStart, via: viaTag)
                        return
                    }
                }
            }
        }

        let topPercent = Int(topConfidence * 100)
        lastDebug = "PRED \(topClass) \(topPercent)% dur=\(String(format: "%.2f", audioDurationS))s margin=\(String(format: "%.2f", topMinusTop2)) dens=\(String(format: "%.1f", density))"
    }

    // ------------------------------------------------------------------
    // Accept candidate
    // ------------------------------------------------------------------
    private func acceptClass(_ newClass: String,
                             audio: [Float],
                             durationS: Double,
                             soundStart: TimeInterval?,
                             via: String) {
        if acceptedClass != nil { nReschedules += 1 }
        acceptedClass = newClass

        if respostaEnabled {
            let bpm = estimateBpm(audio) ?? ChamadaConstants.bpmFallback
            acceptedBpm = bpm

            // Lead-in: override empírico OU canon library OU EXPECTED_BEATS fallback
            let leadIn: Double
            if let override = ChamadaConstants.respostaLeadOverrideS[newClass] {
                leadIn = override
            } else if let canon = CanonicalLibrary.shared.respostaLeadInSeconds(newClass, bpm: bpm) {
                leadIn = canon
            } else if let beats = ChamadaConstants.expectedBeats[newClass] {
                let beatsPerBar = 2.0
                let bars = (beats / beatsPerBar).rounded(.up)
                leadIn = bars * beatsPerBar * 60.0 / bpm
            } else {
                leadIn = (ChamadaConstants.expectedBeats[newClass] ?? 4.0) * 60.0 / bpm
            }

            if let start = soundStart {
                expectedEndTime = start + leadIn
            } else {
                expectedEndTime = Date().timeIntervalSince1970 + leadIn
            }

            print("[Classifier] CANDIDATE \(newClass) (via=\(via), conf=\(Int(currentConfidence * 100))%, bpm=\(Int(bpm)), leadIn=\(String(format: "%.2f", leadIn))s)")
            onCandidate?(newClass, bpm, leadIn)
        } else {
            fireResponse()
        }
    }

    // ------------------------------------------------------------------
    // Fire response — two-stage confirmation
    // ------------------------------------------------------------------
    private func fireResponse() {
        if paused { return }

        bufferLock.lock()
        let bufLen = bufferLen
        let audio = bufLen > 0 ? Array(audioBuffer[0..<bufLen]) : []
        bufferLock.unlock()

        let durationS = Double(audio.count) / Double(Self.sampleRate)
        let candidate = acceptedClass
        var finalClass = candidate
        var finalConfidence = currentConfidence
        var finalProbs = currentProbs ?? [Float](repeating: 0, count: Self.nClasses)

        // Re-classificar full buffer com mesma máscara para confirmar
        if !audio.isEmpty, let probs = runInference(audio) {
            finalProbs = probs
            var masked = probs
            var maskedIdx: [Int] = []
            for i in 0..<Self.nClasses {
                let c = classNames[i]
                if excludedClasses.contains(c) {
                    maskedIdx.append(i)
                    continue
                }
                if durationS < tMinFor(c) {
                    maskedIdx.append(i)
                }
            }
            for i in maskedIdx { masked[i] = 0 }
            let maskedSum = masked.reduce(0, +)
            if maskedSum > 0 {
                var idx = 0
                var bestProb: Float = -.infinity
                for i in 0..<Self.nClasses where masked[i] > bestProb {
                    bestProb = masked[i]
                    idx = i
                }
                let cls = classNames[idx]
                finalClass = cls
                finalConfidence = probs[idx]

                // Density override (same as loop)
                let density = estimateDensity(audio: audio, durationS: durationS)
                if (cls == "chamada-9" || cls == "chamada-10"),
                   density >= densityThreshold {
                    let sortedIdx = masked.enumerated()
                        .filter { $0.element > 0 }
                        .sorted { $0.element > $1.element }
                        .map { $0.offset }
                    let top3 = Array(sortedIdx.prefix(3)).map { classNames[$0] }
                    if top3.contains("chamada-4"),
                       let c4Idx = classNames.firstIndex(of: "chamada-4"),
                       masked[c4Idx] > 0 {
                        finalClass = "chamada-4"
                        finalConfidence = probs[c4Idx]
                    }
                }

                // Density protection: candidate=chamada-4, density alta → manter
                if candidate == "chamada-4", finalClass != "chamada-4",
                   density >= densityThreshold,
                   let c4Idx = classNames.firstIndex(of: "chamada-4"),
                   masked[c4Idx] > 0 {
                    finalClass = "chamada-4"
                    finalConfidence = probs[c4Idx]
                }

                // Bypass protection: se aceitação foi via TUBS bypass
                // (forte evidência via templates), manter candidata mesmo
                // que masked argmax diverja com mais áudio.
                if lastAcceptViaBypass,
                   let cand = candidate,
                   finalClass != cand,
                   let candIdx = classNames.firstIndex(of: cand),
                   masked[candIdx] > 0 {
                    finalClass = cand
                    finalConfidence = probs[candIdx]
                }
            }
        }

        let result = ClassificationResult(
            label: finalClass ?? "none",
            candidate: candidate,
            confirmed: finalClass == candidate,
            confidence: finalConfidence,
            probabilities: finalProbs,
            bpm: acceptedBpm,
            durationS: durationS,
            nReschedules: nReschedules
        )

        paused = true
        let logLabel = finalClass ?? "(none)"
        let logCand = candidate ?? "(none)"
        print("[Classifier] CONFIRMED \(logLabel) (cand=\(logCand), confirmed=\(finalClass == candidate), conf=\(Int(finalConfidence*100))%, dur=\(String(format: "%.2f", durationS))s)")
        onResult?(result)
    }

    // ------------------------------------------------------------------
    // Inference helper
    // ------------------------------------------------------------------
    private func runInference(_ audio: [Float]) -> [Float]? {
        guard let dspState = dspState, let interpreter = interpreter else { return nil }

        var melOut = [Float](repeating: 0, count: Self.attMelSize)
        let rc = audio.withUnsafeBufferPointer { audioPtr in
            melOut.withUnsafeMutableBufferPointer { melPtr in
                repenique_preprocess_attention(dspState, audioPtr.baseAddress!, Int32(audio.count), melPtr.baseAddress!)
            }
        }
        guard rc == 0 else {
            print("[Classifier] preprocess_attention rc=\(rc)")
            return nil
        }

        let inputTensor = TfLiteInterpreterGetInputTensor(interpreter, 0)
        melOut.withUnsafeBufferPointer { ptr in
            TfLiteTensorCopyFromBuffer(inputTensor, ptr.baseAddress!, ptr.count * MemoryLayout<Float>.size)
        }
        guard TfLiteInterpreterInvoke(interpreter) == kTfLiteOk else {
            return nil
        }
        let outputTensor = TfLiteInterpreterGetOutputTensor(interpreter, 0)
        var probs = [Float](repeating: 0, count: Self.nClasses)
        probs.withUnsafeMutableBufferPointer { ptr in
            TfLiteTensorCopyToBuffer(outputTensor, ptr.baseAddress!, ptr.count * MemoryLayout<Float>.size)
        }
        return probs
    }

    // ------------------------------------------------------------------
    // BPM via autocorrelation (range BPM_MIN..BPM_MAX)
    // ------------------------------------------------------------------
    private func estimateBpm(_ audio: [Float]) -> Double? {
        guard let dspState = dspState else { return nil }
        let maxFrames = repenique_max_frames(Int32(audio.count))
        guard maxFrames > 10 else { return nil }

        var envOut = [Float](repeating: 0, count: Int(maxFrames))
        var nFramesOut: Int32 = 0
        let rc = audio.withUnsafeBufferPointer { audioPtr in
            envOut.withUnsafeMutableBufferPointer { envPtr in
                repenique_onset_envelope(dspState, audioPtr.baseAddress!, Int32(audio.count),
                                         envPtr.baseAddress!, &nFramesOut)
            }
        }
        guard rc == 0, nFramesOut >= 10 else { return nil }
        let n = Int(nFramesOut)

        var mean: Double = 0
        for i in 0..<n { mean += Double(envOut[i]) }
        mean /= Double(n)

        let frameDur = Double(Self.hopLength) / Double(Self.sampleRate)
        let minLag = Int(60.0 / (ChamadaConstants.bpmMax * frameDur))
        var maxLag = Int(60.0 / (ChamadaConstants.bpmMin * frameDur))
        maxLag = min(maxLag, n - 1)
        guard minLag < maxLag, minLag < n else { return nil }

        var bestLag = minLag
        var bestVal = -Double.infinity
        for lag in minLag...maxLag {
            var sum: Double = 0
            for i in 0..<(n - lag) {
                sum += (Double(envOut[i]) - mean) * (Double(envOut[i + lag]) - mean)
            }
            if sum > bestVal { bestVal = sum; bestLag = lag }
        }
        return 60.0 / (Double(bestLag) * frameDur)
    }

    // ------------------------------------------------------------------
    // Density estimate via classifier mel-spec + peak-pick
    // (sem TUBS extraction completo — basta n_onsets / duration)
    // ------------------------------------------------------------------
    private func estimateDensity(audio: [Float], durationS: Double) -> Double {
        // pick_peaks é stateless; só precisamos do envelope do DSP base.
        guard let dspState = dspState, durationS >= 0.1 else { return 0 }
        let maxFrames = repenique_max_frames(Int32(audio.count))
        guard maxFrames > 10 else { return 0 }
        var envOut = [Float](repeating: 0, count: Int(maxFrames))
        var nFramesOut: Int32 = 0
        let rc = audio.withUnsafeBufferPointer { audioPtr in
            envOut.withUnsafeMutableBufferPointer { envPtr in
                repenique_onset_envelope(dspState, audioPtr.baseAddress!, Int32(audio.count),
                                         envPtr.baseAddress!, &nFramesOut)
            }
        }
        guard rc == 0, nFramesOut > 5 else { return 0 }

        let peakCapacity = Int(nFramesOut)
        var peaks = [Int32](repeating: 0, count: peakCapacity)
        let frameDur = Double(Self.hopLength) / Double(Self.sampleRate)
        let minDistFrames = max(1, Int(0.030 / frameDur))
        let nPeaks = peaks.withUnsafeMutableBufferPointer { peaksPtr -> Int32 in
            envOut.withUnsafeBufferPointer { envPtr in
                repenique_pick_peaks(envPtr.baseAddress!, nFramesOut,
                                     0.3, Int32(minDistFrames),
                                     peaksPtr.baseAddress!, Int32(peakCapacity))
            }
        }
        if nPeaks <= 0 { return 0 }
        return Double(nPeaks) / max(0.1, durationS)
    }

    // ------------------------------------------------------------------
    // Buffer helpers
    // ------------------------------------------------------------------
    private func appendSamplesLocked(_ samples: [Float]) {
        let needed = samples.count
        if bufferLen + needed > Self.maxBufferSamples {
            let keep = Self.maxBufferSamples - needed
            if keep > 0 {
                audioBuffer.replaceSubrange(0..<keep, with: audioBuffer[(bufferLen - keep)..<bufferLen])
                bufferLen = keep
            } else {
                bufferLen = 0
            }
        }
        for i in 0..<needed {
            audioBuffer[bufferLen + i] = samples[i]
        }
        bufferLen += needed
    }

    func resetBuffer() { hardReset() }

    private func hardReset() {
        bufferLock.lock()
        bufferLen = 0
        hasSound = false
        soundStartTime = nil
        bufferLock.unlock()
        lastSoundTime = 0
        lastClassifyTime = 0
        currentPrediction = nil
        currentConfidence = 0
        currentProbs = nil
        recentPredictions.removeAll()
        acceptedClass = nil
        acceptedBpm = nil
        expectedEndTime = nil
        nReschedules = 0
        yamnetChecked = false
        isPercussion = true
        paused = false
        lastDensity = 0
        lastTubsScores.removeAll()
        lastAcceptViaBypass = false
    }
}
