import Foundation
import Capacitor

@objc(ChamaRepiquePlugin)
public class ChamaRepiquePlugin: CAPPlugin, CAPBridgedPlugin {
    public let identifier = "ChamaRepiquePlugin"
    public let jsName = "ChamaRepique"
    public let pluginMethods: [CAPPluginMethod] = [
        CAPPluginMethod(name: "init", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "start", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "stop", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "updateConfig", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "startLiveDemo", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "stopLiveDemo", returnType: CAPPluginReturnPromise),
    ]

    /// Bundle holding plugin resources (tflite models, beat WAVs, JSON canon).
    /// Populated by `s.resources` in CapacitorChamaRepique.podspec.
    static let resourceBundle = Bundle(for: ChamaRepiquePlugin.self)

    private let capture = AudioCaptureService()
    private let classifier = ChamadaClassifier()
    private let liveDemo = LiveDemoMode()
    private let playback = PlaybackEngine()
    private var isPlaying = false

    private enum Mode { case idle, classifier, liveDemo }
    private var mode: Mode = .idle

    // ------------------------------------------------------------------
    // JS API
    // ------------------------------------------------------------------
    @objc func `init`(_ call: CAPPluginCall) {
        guard classifier.load() else {
            call.reject("Failed to load classifier models")
            return
        }
        guard playback.load() else {
            call.reject("Failed to load playback samples")
            return
        }
        guard liveDemo.load() else {
            call.reject("Failed to init live demo native deps")
            return
        }

        wireCallbacks()
        notifyListeners("log", data: ["message": "Plugin initialized (10-class + live demo)"])
        call.resolve(["status": "initialized"])
    }

    @objc func start(_ call: CAPPluginCall) {
        guard mode == .idle else {
            call.reject("Already running mode=\(mode)")
            return
        }
        applyClassifierConfig(call)
        do {
            try capture.start()
            classifier.start()
            mode = .classifier
            notifyListeners("stateChange", data: ["state": "listening", "rmsLevel": 0, "mode": "classifier"])
            call.resolve(["status": "started", "mode": "classifier"])
        } catch {
            call.reject("Failed to start audio capture: \(error.localizedDescription)")
        }
    }

    @objc func stop(_ call: CAPPluginCall) {
        capture.stop()
        classifier.stop()
        playback.stop()
        playback.clearPreRender()
        liveDemo.stop()
        isPlaying = false
        mode = .idle
        notifyListeners("stateChange", data: ["state": "idle", "rmsLevel": 0, "mode": "idle"])
        call.resolve(["status": "stopped"])
    }

    @objc func updateConfig(_ call: CAPPluginCall) {
        applyClassifierConfig(call)
        applyLiveDemoConfig(call)
        call.resolve(["status": "updated"])
    }

    @objc func startLiveDemo(_ call: CAPPluginCall) {
        guard mode == .idle else {
            call.reject("Already running mode=\(mode)")
            return
        }
        applyLiveDemoConfig(call)
        do {
            try capture.start()
            liveDemo.start()
            mode = .liveDemo
            notifyListeners("stateChange", data: ["state": "live_demo", "rmsLevel": 0, "mode": "liveDemo"])
            call.resolve(["status": "started", "mode": "liveDemo"])
        } catch {
            call.reject("Failed to start audio capture: \(error.localizedDescription)")
        }
    }

    @objc func stopLiveDemo(_ call: CAPPluginCall) {
        liveDemo.stop()
        capture.stop()
        mode = .idle
        notifyListeners("stateChange", data: ["state": "idle", "rmsLevel": 0, "mode": "idle"])
        call.resolve(["status": "stopped"])
    }

    // ------------------------------------------------------------------
    // Internals
    // ------------------------------------------------------------------
    private func applyClassifierConfig(_ call: CAPPluginCall) {
        if let t = call.getDouble("threshold") {
            classifier.threshold = Float(t)
        }
        if let hc = call.getDouble("highConf") {
            classifier.highConfThreshold = Float(hc)
        }
        if let m = call.getDouble("margin") {
            classifier.margin = Float(m)
        }
        if let dt = call.getDouble("densityThreshold") {
            classifier.densityThreshold = dt
        }
        if let arr = call.getArray("excluded") as? [String] {
            classifier.excludedClasses = Set(arr)
        } else if let raw = call.getArray("excluded") {
            let parsed = raw.compactMap { $0 as? String }
            if !parsed.isEmpty { classifier.excludedClasses = Set(parsed) }
        }
        if let resposta = call.getBool("resposta") {
            classifier.respostaEnabled = resposta
        }
        if let yamnet = call.getBool("yamnet") {
            classifier.yamnetEnabled = yamnet
        }
        if let tubs = call.getBool("tubs") {
            classifier.tubsEnabled = tubs
        }
    }

    private func applyLiveDemoConfig(_ call: CAPPluginCall) {
        if let bpm = call.getDouble("bpm") {
            liveDemo.bpm = bpm
        }
        if let bc = call.getInt("barsChamada") {
            liveDemo.barsChamada = bc
        }
        if let br = call.getInt("barsResposta") {
            liveDemo.barsResposta = br
        }
        if let am = call.getDouble("anticipateMs") {
            liveDemo.anticipateMs = am
        }
        if let cv = call.getBool("classifyVoices") {
            liveDemo.classifyVoices = cv
        }
        if let dr = call.getBool("detectRim") {
            liveDemo.detectRim = dr
        }
    }

    private func wireCallbacks() {
        classifier.onCandidate = { [weak self] chamada, bpm, leadInS in
            self?.playback.preRender(chamada: chamada, bpm: bpm)
            self?.notifyListeners("candidate", data: [
                "label": chamada,
                "bpm": bpm,
                "leadInS": leadInS,
            ])
        }
        classifier.onResult = { [weak self] result in
            self?.handleClassifierResult(result)
        }
        classifier.onFrame = { [weak self] frame in
            self?.notifyListeners("frame", data: [
                "topClass": frame.topClass,
                "confidence": frame.confidence,
                "audioDurationS": frame.audioDurationS,
                "masked": frame.masked,
                "density": frame.densityHitsPerSec ?? 0,
            ])
        }
        classifier.onLog = { [weak self] message in
            self?.notifyListeners("log", data: ["message": message])
        }

        liveDemo.onCycleStart = { [weak self] index in
            self?.notifyListeners("liveDemoCycle", data: ["index": index])
        }
        liveDemo.onChamadaTubs = { [weak self] tubs, n in
            self?.notifyListeners("liveDemoChamada", data: ["tubs": tubs, "nOnsets": n])
        }
        liveDemo.onRespostaTubs = { [weak self] tubs in
            self?.notifyListeners("liveDemoResposta", data: ["tubs": tubs])
        }
        liveDemo.onLog = { [weak self] message in
            self?.notifyListeners("log", data: ["message": message])
        }

        capture.onChunk = { [weak self] samples, rms in
            self?.handleAudioChunk(samples: samples, rms: rms)
        }
    }

    private func handleAudioChunk(samples: [Float], rms: Float) {
        guard !isPlaying else { return }
        switch mode {
        case .classifier:
            classifier.addSamples(samples)
        case .liveDemo:
            liveDemo.addSamples(samples)
        case .idle:
            return
        }

        let level = min(Double(rms * 3.0), 1.0)
        notifyListeners("stateChange", data: [
            "state": mode == .liveDemo ? "live_demo" : "listening",
            "rmsLevel": level,
            "debug": classifier.lastDebug,
            "mode": mode == .liveDemo ? "liveDemo" : "classifier",
        ])
    }

    private func handleClassifierResult(_ result: ClassificationResult) {
        if result.label == "none" {
            playback.clearPreRender()
            classifier.resume()
            return
        }

        var probs: [String: Float] = [:]
        for (i, name) in classNames.enumerated() where i < result.probabilities.count {
            probs[name] = result.probabilities[i]
        }

        notifyListeners("chamadaDetected", data: [
            "label": result.label,
            "candidate": result.candidate ?? NSNull(),
            "confirmed": result.confirmed,
            "confidence": result.confidence,
            "bpm": result.bpm ?? ChamadaConstants.bpmFallback,
            "durationS": result.durationS,
            "nReschedules": result.nReschedules,
            "probabilities": probs,
        ])

        isPlaying = true
        classifier.setMuted(true)
        notifyListeners("stateChange", data: ["state": "playing", "rmsLevel": 0, "mode": "classifier"])

        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            guard let self = self else { return }
            _ = self.playback.playResposta(chamada: result.label, bpm: result.bpm)

            let durS = self.estimatedRespostaSeconds(chamada: result.label,
                                                     bpm: result.bpm ?? ChamadaConstants.bpmFallback)
            Thread.sleep(forTimeInterval: durS + 0.2)

            DispatchQueue.main.async {
                self.isPlaying = false
                self.classifier.setMuted(false)
                self.classifier.resetBuffer()
                self.classifier.resume()
                self.notifyListeners("stateChange", data: ["state": "listening", "rmsLevel": 0, "mode": "classifier"])
            }
        }
    }

    private func estimatedRespostaSeconds(chamada: String, bpm: Double) -> Double {
        guard let resolved = CanonicalLibrary.shared.resolveResposta(chamada) else { return 1.0 }
        let slots = resolved.pattern.filter { $0 == "X" || $0 == "." }.count
        let stepS = CanonicalLibrary.slotSeconds(resolution: resolved.resolution, bpm: bpm)
        return Double(slots) * stepS + 0.2
    }
}
