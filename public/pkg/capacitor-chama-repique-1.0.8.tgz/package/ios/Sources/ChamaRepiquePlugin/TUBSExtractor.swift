import Foundation

/// Resultado da extracção TUBS sobre um buffer de áudio.
struct TUBSResult {
    let tubs: String          // formatado com `|` (ex.: "|X.X.....|...|")
    let stripped: String      // sem `|` (input para scorer)
    let onsetsS: [Double]     // tempos dos peaks em segundos
    let nOnsets: Int
    let durationS: Double
    let bpm: Double
}

/// Extrai um TUBS string de um buffer de áudio. Mirror de
/// `scripts/extract_tubs.py:extract_tubs_from_audio` mas usando exclusivamente
/// o engine nativo C++ (`repenique_onset_envelope` + `repenique_pick_peaks`).
///
/// Notas vs Python:
/// - O `librosa.onset.onset_detect` usa peak picking adaptativo + backtrack.
///   Aqui aproximamos com `repenique_pick_peaks` (scipy.signal.find_peaks
///   equivalent). Templates do user_templates_*.json foram extraídos com a
///   versão CNN onset; o score com tolerance=1 absorve bem a variação.
enum TUBSExtractor {
    static let slotsPerBar = 16    // 16 fusas por compasso 2/4 (resolution 32)

    /// Threshold de pick_peaks no envelope (matches default usado em ChamadaClassifier
    /// para density). 0.3 é conservador.
    static let pickThreshold: Float = 0.3
    /// Distância mínima entre peaks (~30ms a 86fps frame rate)
    static let minDistMs: Double = 30

    static func extract(audio: [Float], dspState: OpaquePointer, bpmHint: Double? = nil) -> TUBSResult? {
        guard !audio.isEmpty else { return nil }
        let sr = 44100.0
        let hop = 512.0
        let frameDur = hop / sr
        let durationS = Double(audio.count) / sr

        // 1) Onset envelope
        let maxFrames = repenique_max_frames(Int32(audio.count))
        guard maxFrames > 5 else { return nil }
        var envOut = [Float](repeating: 0, count: Int(maxFrames))
        var nFramesOut: Int32 = 0
        let rc = audio.withUnsafeBufferPointer { audioPtr in
            envOut.withUnsafeMutableBufferPointer { envPtr in
                repenique_onset_envelope(dspState, audioPtr.baseAddress!, Int32(audio.count),
                                         envPtr.baseAddress!, &nFramesOut)
            }
        }
        guard rc == 0, nFramesOut > 5 else { return nil }
        let nFrames = Int(nFramesOut)

        // 2) Peak pick
        let minDistFrames = max(1, Int((minDistMs / 1000.0) / frameDur))
        var peaks = [Int32](repeating: 0, count: nFrames)
        let nPeaks = peaks.withUnsafeMutableBufferPointer { peaksPtr -> Int32 in
            envOut.withUnsafeBufferPointer { envPtr in
                repenique_pick_peaks(envPtr.baseAddress!, Int32(nFrames),
                                     pickThreshold, Int32(minDistFrames),
                                     peaksPtr.baseAddress!, Int32(nFrames))
            }
        }
        guard nPeaks > 0 else {
            return TUBSResult(tubs: "|" + String(repeating: ".", count: slotsPerBar) + "|",
                              stripped: String(repeating: ".", count: slotsPerBar),
                              onsetsS: [], nOnsets: 0,
                              durationS: durationS,
                              bpm: bpmHint ?? ChamadaConstants.bpmFallback)
        }

        let onsetsS: [Double] = (0..<Int(nPeaks)).map { Double(peaks[$0]) * frameDur }

        // 3) BPM: hint ou autocorr fallback
        let bpm: Double
        if let h = bpmHint, h > 0 {
            bpm = h
        } else if let est = autocorrBpm(env: envOut, nFrames: nFrames, frameDur: frameDur) {
            bpm = est
        } else {
            bpm = ChamadaConstants.bpmFallback
        }

        // 4) Quantize → fusas
        let tubs = quantizeToTubs(onsets: onsetsS, bpm: bpm, durationS: durationS)
        let stripped = tubs.replacingOccurrences(of: "|", with: "")
        return TUBSResult(tubs: tubs, stripped: stripped, onsetsS: onsetsS,
                          nOnsets: Int(nPeaks), durationS: durationS, bpm: bpm)
    }

    /// Autocorrelação de envelope para estimar BPM (mesmo algoritmo que
    /// `ChamadaClassifier.estimateBpm`, mas operando no envelope já
    /// computado). Range 120-145 (ChamadaConstants.bpmMin/Max).
    private static func autocorrBpm(env: [Float], nFrames: Int, frameDur: Double) -> Double? {
        var mean: Double = 0
        for i in 0..<nFrames { mean += Double(env[i]) }
        mean /= Double(nFrames)
        let minLag = Int(60.0 / (ChamadaConstants.bpmMax * frameDur))
        var maxLag = Int(60.0 / (ChamadaConstants.bpmMin * frameDur))
        maxLag = min(maxLag, nFrames - 1)
        guard minLag < maxLag, minLag < nFrames else { return nil }
        var bestLag = minLag
        var bestVal = -Double.infinity
        for lag in minLag...maxLag {
            var sum: Double = 0
            for i in 0..<(nFrames - lag) {
                sum += (Double(env[i]) - mean) * (Double(env[i + lag]) - mean)
            }
            if sum > bestVal { bestVal = sum; bestLag = lag }
        }
        return 60.0 / (Double(bestLag) * frameDur)
    }

    /// Snap de onsets a uma grelha de fusas (1/32). 1 fusa = 60/bpm/8 segundos.
    /// Primeiro onset alinha em slot 0; restantes seguem a grelha relativa.
    private static func quantizeToTubs(onsets: [Double], bpm: Double, durationS: Double) -> String {
        guard !onsets.isEmpty else {
            return "|" + String(repeating: ".", count: slotsPerBar) + "|"
        }
        let fusaS = 60.0 / bpm / 8.0
        let barS = fusaS * Double(slotsPerBar)
        let t0 = onsets[0]
        let span = max(durationS - t0, (onsets.last ?? t0) - t0 + barS / 2)
        let nBars = max(1, Int((span / barS).rounded(.up)))
        let nSlots = nBars * slotsPerBar
        var slots = [Character](repeating: ".", count: nSlots)
        for t in onsets {
            let slot = Int(((t - t0) / fusaS).rounded())
            if slot >= 0, slot < nSlots {
                slots[slot] = "X"
            }
        }
        var bars: [String] = []
        var idx = 0
        while idx < nSlots {
            bars.append(String(slots[idx..<min(idx + slotsPerBar, nSlots)]))
            idx += slotsPerBar
        }
        return "|" + bars.joined(separator: "|") + "|"
    }
}
