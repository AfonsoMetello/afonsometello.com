require 'json'

package = JSON.parse(File.read(File.join(__dir__, 'package.json')))

Pod::Spec.new do |s|
  s.name         = 'CapacitorChamaRepique'
  s.version      = package['version']
  s.summary      = package['description']
  s.homepage     = 'https://github.com/sambahero/capacitor-chama-repique'
  s.license      = { :type => 'Proprietary' }
  s.author       = package['author']
  s.source       = { :git => 'https://github.com/sambahero/capacitor-chama-repique.git', :tag => s.version.to_s }

  s.ios.deployment_target = '15.0'
  s.swift_version = '5.9'
  s.static_framework = true

  # Swift plugin source + C++ DSP source (embedded)
  s.source_files = [
    'ios/Sources/**/*.{swift,m}',
    'native/src/**/*.{cpp,c,h}',
    'native/include/**/*.h',
    'native/vendor/kissfft/**/*.{c,h}'
  ]

  # Expose the clean C API only. Internal headers (repenique_tables.h, kissfft)
  # use bare struct names (no typedefs) and can't be parsed by Clang when
  # building the Swift module PCM.
  s.public_header_files = [
    'native/include/repenique_dsp.h',
    'native/include/repenique_classifier.h',
  ]

  # Resources bundled into the plugin framework bundle:
  # - *.tflite: 10-class attention, yamnet, onset_cnn, rim_classifier, voice_classifier
  # - *.wav: beat samples for response playback
  # - *.json: canon TUBS library + per-class user templates for bypass scoring
  s.resources = [
    'ios/Resources/**/*.tflite',
    'ios/Resources/**/*.wav',
    'ios/Resources/**/*.json',
  ]

  # Dependencies
  s.dependency 'Capacitor'
  s.dependency 'CapacitorCordova'
  s.dependency 'TensorFlowLiteC', '~> 2.12.0'

  # C++ build settings
  s.pod_target_xcconfig = {
    'CLANG_CXX_LANGUAGE_STANDARD' => 'c++17',
    'GCC_C_LANGUAGE_STANDARD' => 'c99',
    'GCC_PREPROCESSOR_DEFINITIONS' => '$(inherited) kiss_fft_scalar=float',
    'HEADER_SEARCH_PATHS' => [
      '"${PODS_TARGET_SRCROOT}/native/include"',
      '"${PODS_TARGET_SRCROOT}/native/src"',
      '"${PODS_TARGET_SRCROOT}/native/vendor/kissfft"'
    ].join(' '),
    'OTHER_CFLAGS' => '-O3 -ffast-math'
  }
end
