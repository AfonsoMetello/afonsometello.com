import Foundation
import AVFoundation

/// Captures PCM audio from the microphone via AVAudioEngine.
/// Delivers float32 mono 44100Hz chunks via callback.
class AudioCaptureService {
    typealias ChunkCallback = (_ samples: [Float], _ rms: Float) -> Void

    private let engine = AVAudioEngine()
    private let sampleRate: Double = 44100
    private let bufferSize: AVAudioFrameCount = 1024
    private var isRunning = false
    var onChunk: ChunkCallback?

    func start() throws {
        guard !isRunning else { return }

        let session = AVAudioSession.sharedInstance()
        try session.setCategory(.playAndRecord, options: [.defaultToSpeaker])
        try session.setPreferredSampleRate(sampleRate)
        try session.setActive(true)

        // Select USB > built-in mic (never Bluetooth)
        selectPreferredMic()

        let inputNode = engine.inputNode
        let hwFormat = inputNode.inputFormat(forBus: 0)

        // Convert to mono 44100Hz float32
        guard let targetFormat = AVAudioFormat(
            commonFormat: .pcmFormatFloat32,
            sampleRate: sampleRate,
            channels: 1,
            interleaved: false
        ) else {
            throw NSError(domain: "AudioCapture", code: -1,
                          userInfo: [NSLocalizedDescriptionKey: "Failed to create target format"])
        }

        guard let converter = AVAudioConverter(from: hwFormat, to: targetFormat) else {
            throw NSError(domain: "AudioCapture", code: -2,
                          userInfo: [NSLocalizedDescriptionKey: "Failed to create converter"])
        }

        inputNode.installTap(onBus: 0, bufferSize: bufferSize, format: hwFormat) { [weak self] buffer, _ in
            guard let self = self else { return }

            guard let convertedBuffer = AVAudioPCMBuffer(
                pcmFormat: targetFormat,
                frameCapacity: AVAudioFrameCount(Double(buffer.frameLength) * self.sampleRate / hwFormat.sampleRate)
            ) else { return }

            var error: NSError?
            let status = converter.convert(to: convertedBuffer, error: &error) { _, outStatus in
                outStatus.pointee = .haveData
                return buffer
            }
            guard status != .error, error == nil else { return }

            let count = Int(convertedBuffer.frameLength)
            guard count > 0, let channelData = convertedBuffer.floatChannelData?[0] else { return }

            let samples = Array(UnsafeBufferPointer(start: channelData, count: count))

            // Compute RMS
            var sum: Float = 0
            for s in samples { sum += s * s }
            let rms = sqrtf(sum / Float(count))

            self.onChunk?(samples, rms)
        }

        try engine.start()
        isRunning = true
    }

    func stop() {
        guard isRunning else { return }
        engine.inputNode.removeTap(onBus: 0)
        engine.stop()
        isRunning = false
    }

    /// Mic priority: USB > built-in (never Bluetooth/AirPods).
    private func selectPreferredMic() {
        let session = AVAudioSession.sharedInstance()
        guard let inputs = session.availableInputs else { return }

        // Prefer USB
        if let usb = inputs.first(where: { $0.portType == .usbAudio }) {
            try? session.setPreferredInput(usb)
            return
        }
        // Fallback to built-in
        if let builtIn = inputs.first(where: { $0.portType == .builtInMic }) {
            try? session.setPreferredInput(builtIn)
        }
    }
}
