import Foundation
import AVFoundation

/// Plays response patterns using pre-decoded beat WAV samples.
/// Ported from playback_engine.dart.
class PlaybackEngine {
    private static let sampleRate = 44100
    private static let defaultBpm: Double = 130.0
    private static let sampleCount = 10

    private var player: AVAudioPlayer?
    private var beats: [[Float]] = []
    private var lastSampleIdx = -1
    private var tempDir: String?

    // Pre-rendered response
    private var preRenderedChamada: String?
    private var preRenderedPath: String?

    func load() -> Bool {
        tempDir = NSTemporaryDirectory()

        for i in 1...Self.sampleCount {
            let name = String(format: "beat%02d", i)
            guard let path = ChamaRepiquePlugin.resourceBundle.path(forResource: name, ofType: "wav") else {
                ChamaRepiqueLog.log("Playback", "Beat sample \(name).wav not found")
                return false
            }

            guard let data = try? Data(contentsOf: URL(fileURLWithPath: path)) else {
                ChamaRepiqueLog.log("Playback", "Failed to read \(name).wav")
                return false
            }

            let pcm = decodeWav(Array(data))
            beats.append(pcm)
            ChamaRepiqueLog.log("Playback", "Loaded \(name).wav: \(pcm.count) samples (\(Int(Double(pcm.count) / Double(Self.sampleRate) * 1000))ms)")
        }

        ChamaRepiqueLog.log("Playback", "Init done, \(beats.count) beats loaded")
        return true
    }

    /// Pre-render a response WAV (called at acceptance time).
    func preRender(chamada: String, bpm: Double) {
        guard let resolved = CanonicalLibrary.shared.resolveResposta(chamada),
              !beats.isEmpty,
              let tempDir = tempDir else { return }

        guard let wav = renderPattern(resolved.pattern,
                                      resolution: resolved.resolution,
                                      bpm: bpm) else { return }

        let path = "\(tempDir)/resposta_pre_\(chamada).wav"
        let url = URL(fileURLWithPath: path)
        try? Data(wav).write(to: url)
        preRenderedChamada = chamada
        preRenderedPath = path
        ChamaRepiqueLog.log("Playback", "Pre-rendered \(chamada) (bpm=\(Int(bpm)), res=\(resolved.resolution))")
    }

    func clearPreRender() {
        preRenderedChamada = nil
        preRenderedPath = nil
    }

    /// Play the response for a detected chamada.
    func playResposta(chamada: String, bpm: Double?) -> Bool {
        guard let resolved = CanonicalLibrary.shared.resolveResposta(chamada), !beats.isEmpty else {
            ChamaRepiqueLog.log("Playback", "No canon resposta for \(chamada) or no beats loaded")
            return false
        }
        let effectiveBpm = bpm ?? Self.defaultBpm

        let path: String
        if preRenderedChamada == chamada, let prePath = preRenderedPath {
            path = prePath
            ChamaRepiqueLog.log("Playback", "Using pre-rendered \(chamada)")
        } else {
            guard let wav = renderPattern(resolved.pattern,
                                          resolution: resolved.resolution,
                                          bpm: effectiveBpm),
                  let tempDir = tempDir else { return false }

            path = "\(tempDir)/resposta_\(chamada).wav"
            let url = URL(fileURLWithPath: path)
            try? Data(wav).write(to: url)
        }
        clearPreRender()

        ChamaRepiqueLog.log("Playback", "Playing \(chamada) (bpm=\(Int(effectiveBpm)), res=\(resolved.resolution))")

        do {
            player = try AVAudioPlayer(contentsOf: URL(fileURLWithPath: path))
            player?.play()
            return true
        } catch {
            ChamaRepiqueLog.log("Playback", "Error: \(error)")
            return false
        }
    }

    func stop() {
        player?.stop()
        player = nil
    }

    func dispose() {
        stop()
    }

    // MARK: - Rendering

    /// Renderiza um pattern TUBS para PCM WAV.
    /// `resolution` é a resolução do pattern (ex.: 32 = fusa, 16 = sixteenth).
    /// 1 slot = 60 / bpm / (resolution / 4) segundos.
    private func renderPattern(_ pattern: String, resolution: Int, bpm: Double) -> [UInt8]? {
        let slots = pattern.compactMap { c -> Character? in
            c == "X" || c == "." ? c : nil
        }
        guard !slots.isEmpty else { return nil }

        let hitSlots = slots.enumerated().compactMap { $0.element == "X" ? $0.offset : nil }
        guard !hitSlots.isEmpty else { return nil }

        let stepS = CanonicalLibrary.slotSeconds(resolution: resolution, bpm: bpm)
        let maxBeatLen = beats.map(\.count).max() ?? 0
        let totalSamples = Int(Double(slots.count) * stepS * Double(Self.sampleRate)) + maxBeatLen
        var audio = [Float](repeating: 0, count: totalSamples)

        let lastHitSlot = hitSlots.last!

        for slotIdx in hitSlots {
            let isLast = slotIdx == lastHitSlot

            // Sample randomly chosen, excluindo o último tocado
            var sampleIdx: Int
            repeat {
                sampleIdx = Int.random(in: 0..<Self.sampleCount)
            } while sampleIdx == lastSampleIdx && Self.sampleCount > 1
            lastSampleIdx = sampleIdx

            let beat = beats[sampleIdx]

            // Volume: random ±2dB; último hit 0 a +2dB
            let dbOffset = isLast ? Double.random(in: 0...2) : Double.random(in: -2...2)
            let gain = Float(pow(10, dbOffset / 20))

            let basePos = Int(round(Double(slotIdx) * stepS * Double(Self.sampleRate)))

            for j in 0..<beat.count where basePos + j < totalSamples {
                audio[basePos + j] += beat[j] * gain
            }
        }

        return encodeWav(audio)
    }

    // MARK: - WAV codec

    private func decodeWav(_ wavBytes: [UInt8]) -> [Float] {
        var offset = 12
        while offset + 8 < wavBytes.count {
            let chunkId = String(bytes: wavBytes[offset..<offset+4], encoding: .ascii) ?? ""
            let chunkSize = Int(wavBytes[offset+4]) |
                           (Int(wavBytes[offset+5]) << 8) |
                           (Int(wavBytes[offset+6]) << 16) |
                           (Int(wavBytes[offset+7]) << 24)
            if chunkId == "data" {
                offset += 8
                let nSamples = chunkSize / 2
                var floats = [Float](repeating: 0, count: nSamples)
                for i in 0..<nSamples {
                    let lo = UInt16(wavBytes[offset + i * 2])
                    let hi = UInt16(wavBytes[offset + i * 2 + 1])
                    let unsigned: UInt16 = lo | (hi << 8)
                    let signed = Int16(bitPattern: unsigned)
                    floats[i] = Float(signed) / 32768.0
                }
                return floats
            }
            offset += 8 + chunkSize
            if chunkSize % 2 != 0 { offset += 1 }
        }
        return []
    }

    private func encodeWav(_ samples: [Float]) -> [UInt8] {
        let nSamples = samples.count
        let dataSize = nSamples * 2
        let fileSize = 44 + dataSize
        var buf = [UInt8](repeating: 0, count: fileSize)

        // RIFF header
        buf[0] = 0x52; buf[1] = 0x49; buf[2] = 0x46; buf[3] = 0x46
        writeUInt32(&buf, offset: 4, value: UInt32(fileSize - 8))
        buf[8] = 0x57; buf[9] = 0x41; buf[10] = 0x56; buf[11] = 0x45

        // fmt chunk
        buf[12] = 0x66; buf[13] = 0x6D; buf[14] = 0x74; buf[15] = 0x20
        writeUInt32(&buf, offset: 16, value: 16) // chunk size
        writeUInt16(&buf, offset: 20, value: 1)  // PCM
        writeUInt16(&buf, offset: 22, value: 1)  // mono
        writeUInt32(&buf, offset: 24, value: UInt32(Self.sampleRate))
        writeUInt32(&buf, offset: 28, value: UInt32(Self.sampleRate * 2))
        writeUInt16(&buf, offset: 32, value: 2)  // block align
        writeUInt16(&buf, offset: 34, value: 16) // bits per sample

        // data chunk
        buf[36] = 0x64; buf[37] = 0x61; buf[38] = 0x74; buf[39] = 0x61
        writeUInt32(&buf, offset: 40, value: UInt32(dataSize))

        for i in 0..<nSamples {
            let val = Int16(clamping: Int(samples[i] * 32767))
            buf[44 + i * 2] = UInt8(val & 0xFF)
            buf[44 + i * 2 + 1] = UInt8((val >> 8) & 0xFF)
        }

        return buf
    }

    private func writeUInt32(_ buf: inout [UInt8], offset: Int, value: UInt32) {
        buf[offset] = UInt8(value & 0xFF)
        buf[offset + 1] = UInt8((value >> 8) & 0xFF)
        buf[offset + 2] = UInt8((value >> 16) & 0xFF)
        buf[offset + 3] = UInt8((value >> 24) & 0xFF)
    }

    private func writeUInt16(_ buf: inout [UInt8], offset: Int, value: UInt16) {
        buf[offset] = UInt8(value & 0xFF)
        buf[offset + 1] = UInt8((value >> 8) & 0xFF)
    }
}
