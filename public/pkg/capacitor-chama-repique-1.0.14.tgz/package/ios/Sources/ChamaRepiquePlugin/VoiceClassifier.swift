import Foundation
import TensorFlowLiteC

/// 4-class voice classifier — wrap de `voice_classifier.tflite`.
///
/// Classes (ordem matches training em `auto_label_voices_dataset.py`):
///   0 = X (hit)
///   1 = C (centro)
///   2 = R (rim)
///   3 = M (mute)
///
/// Input: 100ms @ 44100Hz → mel-spec 64×10 → TFLite → 4 logits → softmax.
final class VoiceClassifier {
    private var interpreter: OpaquePointer?
    private var model: OpaquePointer?
    private var classifierState: OpaquePointer?

    private static let labels = ["X", "C", "R", "M"]

    func load() -> Bool {
        classifierState = repenique_classifier_init()
        guard classifierState != nil else { return false }
        guard let path = ChamaRepiquePlugin.resourceBundle.path(forResource: "voice_classifier", ofType: "tflite") else {
            ChamaRepiqueLog.log("VoiceClf", "model not found")
            return false
        }
        model = TfLiteModelCreateFromFile(path)
        let opts = TfLiteInterpreterOptionsCreate()
        TfLiteInterpreterOptionsSetNumThreads(opts, 1)
        interpreter = TfLiteInterpreterCreate(model, opts)
        TfLiteInterpreterOptionsDelete(opts)
        guard interpreter != nil,
              TfLiteInterpreterAllocateTensors(interpreter) == kTfLiteOk else {
            return false
        }
        // Warmup
        let dummy = [Float](repeating: 0.001, count: Int(REPENIQUE_CLF_WIN_SAMPLES))
        _ = classify(dummy)
        ChamaRepiqueLog.log("VoiceClf", "Loaded + warmup")
        return true
    }

    /// Classifica um chunk de 100ms. Retorna o label top-1: "X" / "C" / "R" / "M".
    func classify(_ chunk: [Float]) -> String {
        guard let st = classifierState, let interp = interpreter else { return "X" }
        let target = Int(REPENIQUE_CLF_WIN_SAMPLES)
        var input = [Float](repeating: 0, count: target)
        let n = min(chunk.count, target)
        for i in 0..<n { input[i] = chunk[i] }

        var mel = [Float](repeating: 0, count: Int(REPENIQUE_CLF_OUT_SIZE))
        let rc = input.withUnsafeBufferPointer { audioPtr in
            mel.withUnsafeMutableBufferPointer { melPtr in
                repenique_classifier_mel_spec(st, audioPtr.baseAddress!, melPtr.baseAddress!)
            }
        }
        guard rc == 0 else { return "X" }

        let inT = TfLiteInterpreterGetInputTensor(interp, 0)
        mel.withUnsafeBufferPointer { ptr in
            TfLiteTensorCopyFromBuffer(inT, ptr.baseAddress!, ptr.count * MemoryLayout<Float>.size)
        }
        guard TfLiteInterpreterInvoke(interp) == kTfLiteOk else { return "X" }

        let outT = TfLiteInterpreterGetOutputTensor(interp, 0)
        var logits = [Float](repeating: 0, count: 4)
        logits.withUnsafeMutableBufferPointer { ptr in
            TfLiteTensorCopyToBuffer(outT, ptr.baseAddress!, ptr.count * MemoryLayout<Float>.size)
        }
        var bestIdx = 0
        var best: Float = -.infinity
        for i in 0..<4 where logits[i] > best {
            best = logits[i]
            bestIdx = i
        }
        return Self.labels[bestIdx]
    }

    func dispose() {
        if let interpreter = interpreter { TfLiteInterpreterDelete(interpreter) }
        if let model = model { TfLiteModelDelete(model) }
        if let st = classifierState { repenique_classifier_free(st) }
        interpreter = nil
        model = nil
        classifierState = nil
    }
}
