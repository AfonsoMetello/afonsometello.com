import Foundation

/// Canonical 10-class names. Order MUST match phase1_classifier.tflite softmax outputs.
/// Source: data/experiment-results/production/results.json — classes are stored
/// in alphabetical (lexicographic) order, so chamada-10 sits at index 1, not 9.
let classNames = [
    "chamada-1", "chamada-10", "chamada-2", "chamada-3", "chamada-4",
    "chamada-5", "chamada-6", "chamada-7", "chamada-8", "chamada-9",
]

/// Empirical tunables ported from scripts/identify_chamada.py.
/// Source of truth: docs/chamada-evaluation-2026-04-27.md +
/// experiments/early-exit/early_exit_summary_prefix203.txt.
enum ChamadaConstants {
    // Pipeline cadence (matches Python identify_chamada.py)
    static let classifyIntervalS: Double = 0.15
    static let silenceGapS: Double = 0.4
    static let hardResetS: Double = 1.0
    static let minAudioS: Double = 0.5
    static let pollIntervalS: Double = 0.05
    static let sameN: Int = 3

    // BPM band (repenique in user's tuned setup)
    static let bpmMin: Double = 120
    static let bpmMax: Double = 145
    static let bpmFallback: Double = 130

    // Defaults for the global knobs (overridable via plugin config)
    static let defaultThreshold: Float = 0.70
    static let defaultHighConf: Float = 0.90
    static let defaultMargin: Float = 0.20
    static let defaultDensityThreshold: Double = 4.5

    // Default-excluded classes (chamada-2 confunde com chamada-1 e o cenário em palco
    // raramente usa só uma curta marcação isolada).
    static let defaultExcludedClasses: Set<String> = ["chamada-2"]

    /// Mínimo de áudio (s) antes de aceitar cada classe como candidata.
    /// Derivado da análise early-exit sobre o modelo de produção.
    static let tMinS: [String: Double] = [
        "chamada-1": 1.0,
        "chamada-2": 0.3,
        "chamada-3": 1.0,
        "chamada-4": 1.25,
        "chamada-5": 0.5,
        "chamada-6": 1.25,
        "chamada-7": 1.0,
        "chamada-8": 3.0,
        "chamada-9": 2.5,
        "chamada-10": 2.5,
    ]
    static let tMinDefault: Double = 1.5

    /// Threshold per-class para same3 (override do global).
    static let tPerClass: [String: Float] = [
        "chamada-1": 0.50,
        "chamada-4": 0.40,
        "chamada-6": 0.40,
        "chamada-7": 0.40,
        "chamada-10": 0.65,
    ]

    /// High-conf shortcut: aceita à primeira frame se conf passar este nível.
    static let highConfPerClass: [String: Float] = [
        "chamada-1": 0.65,
        "chamada-3": 0.80,
        "chamada-4": 0.75,
        "chamada-6": 0.70,
        "chamada-7": 0.55,
        "chamada-10": 0.80,
    ]

    /// Quarter-note beats esperados por chamada (para speculative scheduling).
    /// expected_duration = expectedBeats[cls] * 60 / bpm.
    static let expectedBeats: [String: Double] = [
        "chamada-1": 4.98,
        "chamada-2": 5.11,
        "chamada-3": 3.91,
        "chamada-4": 9.87,
        "chamada-5": 5.51,
        "chamada-6": 5.39,
        "chamada-7": 5.37,
        "chamada-8": 16.27,
        "chamada-9": 9.37,
        "chamada-10": 6.50,
    ]

    /// Override do lead-in da resposta (s desde sound_start até primeiro hit
    /// canónico). Tunado quando a library não bate com o que o user toca.
    static let respostaLeadOverrideS: [String: Double] = [
        "chamada-4": 4.0,
        "chamada-7": 1.5,
        "chamada-8": 5.5,
        "chamada-10": 4.5,
    ]

    /// Classes onde o TUBS bypass score-based pode dar override ao softmax.
    static let tubsBypassClasses: Set<String> = ["chamada-1", "chamada-3", "chamada-4", "chamada-10"]
    static let tubsBypassThreshold: Float = 0.70
    static let tubsBypassMinConf: [String: Float] = [
        "chamada-3": 0.50,
    ]
}

/// Threshold same3 efectivo para uma classe.
func sameThresholdFor(_ chamada: String, fallback: Float = ChamadaConstants.defaultThreshold) -> Float {
    ChamadaConstants.tPerClass[chamada] ?? fallback
}

/// High-conf shortcut threshold para uma classe.
func highConfFor(_ chamada: String, fallback: Float = ChamadaConstants.defaultHighConf) -> Float {
    ChamadaConstants.highConfPerClass[chamada] ?? fallback
}

/// Mínimo de áudio (s) para aceitar candidata.
func tMinFor(_ chamada: String) -> Double {
    ChamadaConstants.tMinS[chamada] ?? ChamadaConstants.tMinDefault
}

/// Duração esperada da chamada (s) ao BPM dado.
func expectedDurationSeconds(_ chamada: String, bpm: Double) -> Double? {
    guard let beats = ChamadaConstants.expectedBeats[chamada] else { return nil }
    return beats * 60.0 / bpm
}
