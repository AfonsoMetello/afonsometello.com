import Foundation
import os.log

/// Diagnostic logger triple-target:
///   1) `os_log` → visible em Console.app e `idevicesyslog` mesmo em
///      release/MABS builds (`print()` não chega lá).
///   2) `print()` → sandbox / Xcode debug runs.
///   3) Ficheiro em `Documents/repenique-debug.log` → retrievable offline
///      via `getDebugLog` plugin method.
///
/// Uso: `ChamaRepiqueLog.log("Classifier", "iter dur=2.4s ...")`
enum ChamaRepiqueLog {
    private static let logger = OSLog(subsystem: "com.afonsometello.chamarepique", category: "diag")

    /// Tag normalmente é o componente (e.g., "Classifier", "OnsetCNN").
    static func log(_ tag: String, _ message: String) {
        let formatted = "[\(tag)] \(message)"
        os_log("%{public}@", log: logger, type: .default, formatted)
        print(formatted)
        FileLog.shared.append(formatted)
    }
}

/// Append-only writer para o ficheiro de debug, thread-safe via uma queue
/// dedicada. O caller não bloqueia.
final class FileLog {
    static let shared = FileLog()

    private let queue = DispatchQueue(label: "ChamaRepique.FileLog")
    private let url: URL
    private static let formatter: DateFormatter = {
        let f = DateFormatter()
        f.dateFormat = "HH:mm:ss.SSS"
        f.locale = Locale(identifier: "en_US_POSIX")
        return f
    }()

    private init() {
        let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first
            ?? URL(fileURLWithPath: NSTemporaryDirectory())
        url = docs.appendingPathComponent("repenique-debug.log")
    }

    func append(_ message: String) {
        let stamp = Self.formatter.string(from: Date())
        let line = "\(stamp) \(message)\n"
        queue.async { [url] in
            guard let data = line.data(using: .utf8) else { return }
            if FileManager.default.fileExists(atPath: url.path) {
                if let handle = try? FileHandle(forWritingTo: url) {
                    handle.seekToEndOfFile()
                    handle.write(data)
                    try? handle.close()
                }
            } else {
                try? data.write(to: url)
            }
        }
    }

    func contents() -> String {
        guard let data = try? Data(contentsOf: url),
              let str = String(data: data, encoding: .utf8) else {
            return ""
        }
        return str
    }

    func clear() {
        queue.async { [url] in
            try? FileManager.default.removeItem(at: url)
        }
    }

    var path: String { url.path }
}
