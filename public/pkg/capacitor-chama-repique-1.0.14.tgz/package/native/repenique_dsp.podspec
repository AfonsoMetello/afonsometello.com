Pod::Spec.new do |s|
  s.name         = 'repenique_dsp'
  s.version      = '1.2.0'
  s.summary      = 'Repenique DSP feature extraction'
  s.homepage     = 'https://github.com/sambahero'
  s.license      = { :type => 'Proprietary' }
  s.author       = 'SambaHero'
  s.source       = { :path => '.' }

  s.ios.deployment_target = '13.0'

  s.source_files = 'src/**/*.{cpp,c,h}',
                   'include/**/*.h',
                   'vendor/kissfft/**/*.{c,h}'

  s.public_header_files = 'include/repenique_dsp.h'

  s.pod_target_xcconfig = {
    'CLANG_CXX_LANGUAGE_STANDARD' => 'c++17',
    'GCC_C_LANGUAGE_STANDARD' => 'c99',
    'GCC_PREPROCESSOR_DEFINITIONS' => '$(inherited) kiss_fft_scalar=float',
    'HEADER_SEARCH_PATHS' => '"${PODS_TARGET_SRCROOT}/include" "${PODS_TARGET_SRCROOT}/src" "${PODS_TARGET_SRCROOT}/vendor/kissfft"',
    'OTHER_CFLAGS' => '-O3 -ffast-math'
  }
end
