/**
 * Repenique Classifier DSP — Phase 2 pre-processing.
 *
 * Implementação self-contained do mel-spec usado pelos classifiers (rim,
 * voice) e do peak picking sobre onset envelope. Match exacto com:
 *
 *   torchaudio.transforms.MelSpectrogram(
 *       sample_rate=44100, n_fft=1024, hop_length=441,
 *       n_mels=64, f_min=40, f_max=12000, power=2.0,
 *   )
 *
 * Independente de repenique_dsp.h — tem seus próprios FFT plan e tabelas.
 * Segue convenção torchaudio: center=True (reflect padding n_fft/2 cada lado),
 * window=hann (periodic), HTK mel scale.
 */

#include "repenique_classifier.h"
#include "../vendor/kissfft/kiss_fftr.h"

#include <cmath>
#include <cstdlib>
#include <cstring>
#include <algorithm>
#include <vector>

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

#define N_BINS  (REPENIQUE_CLF_N_FFT / 2 + 1)  /* 513 */

struct repenique_classifier_state {
    kiss_fftr_cfg fft_cfg;
    float hann[REPENIQUE_CLF_N_FFT];
    /* mel filterbank: 64 × 513 (n_mels × n_bins), row-major */
    float mel_fb[REPENIQUE_CLF_N_MELS * N_BINS];
    /* scratch */
    float padded[REPENIQUE_CLF_WIN_SAMPLES + REPENIQUE_CLF_N_FFT];
    float frame_buf[REPENIQUE_CLF_N_FFT];
    kiss_fft_cpx cpx_out[N_BINS];
    float power_col[N_BINS];
};

/* ---------------- helpers ---------------- */

static float htk_hz_to_mel(float hz) {
    return 2595.0f * log10f(1.0f + hz / 700.0f);
}
static float htk_mel_to_hz(float mel) {
    return 700.0f * (powf(10.0f, mel / 2595.0f) - 1.0f);
}

static void build_hann_window(float* w, int n) {
    /* Periodic hann: w[n] = 0.5 * (1 - cos(2*pi*n / N)) */
    for (int i = 0; i < n; ++i) {
        w[i] = 0.5f * (1.0f - cosf(2.0f * (float)M_PI * i / (float)n));
    }
}

static void build_mel_filterbank(float* fb, int n_mels, int n_bins,
                                  float sr, float fmin, float fmax) {
    /* mel_points: n_mels + 2 pontos uniformes no domínio mel */
    float mel_min = htk_hz_to_mel(fmin);
    float mel_max = htk_hz_to_mel(fmax);
    float bin_freqs[REPENIQUE_CLF_N_MELS + 2];
    for (int i = 0; i < n_mels + 2; ++i) {
        float mel = mel_min + (mel_max - mel_min) * (float)i / (float)(n_mels + 1);
        float hz = htk_mel_to_hz(mel);
        /* Convert Hz to FFT bin index (float) */
        bin_freqs[i] = hz * (float)REPENIQUE_CLF_N_FFT / sr;
    }
    std::memset(fb, 0, sizeof(float) * n_mels * n_bins);
    for (int m = 0; m < n_mels; ++m) {
        float left = bin_freqs[m];
        float center = bin_freqs[m + 1];
        float right = bin_freqs[m + 2];
        for (int b = 0; b < n_bins; ++b) {
            float bf = (float)b;
            float w = 0.0f;
            if (bf > left && bf < center) {
                w = (bf - left) / (center - left);
            } else if (bf >= center && bf < right) {
                w = (right - bf) / (right - center);
            }
            if (w < 0.0f) w = 0.0f;
            fb[m * n_bins + b] = w;
        }
    }
}

/* Reflect padding: pad_left + audio + pad_right
 * REFLECT (sem repetir borda) = audio[pad..1] + audio + audio[n-2..n-pad-1] */
static void reflect_pad(const float* audio, int n, int pad,
                        float* out) {
    /* Left: reflect skipping the boundary sample */
    for (int i = 0; i < pad; ++i) {
        int src = pad - i;  /* indices: pad, pad-1, ..., 1 */
        if (src >= n) src = 2 * n - src - 2; /* clamp safely */
        if (src < 0) src = 0;
        out[i] = audio[src];
    }
    /* Centre: copy original */
    std::memcpy(out + pad, audio, sizeof(float) * n);
    /* Right: reflect from end */
    for (int i = 0; i < pad; ++i) {
        int src = n - 2 - i;  /* n-2, n-3, ..., n-1-pad */
        if (src < 0) src = 0;
        if (src >= n) src = n - 1;
        out[pad + n + i] = audio[src];
    }
}

/* ---------------- public API ---------------- */

repenique_classifier_state* repenique_classifier_init(void) {
    repenique_classifier_state* st =
        (repenique_classifier_state*)calloc(1, sizeof(repenique_classifier_state));
    if (!st) return nullptr;

    st->fft_cfg = kiss_fftr_alloc(REPENIQUE_CLF_N_FFT, 0, nullptr, nullptr);
    if (!st->fft_cfg) {
        free(st);
        return nullptr;
    }

    build_hann_window(st->hann, REPENIQUE_CLF_N_FFT);
    build_mel_filterbank(st->mel_fb, REPENIQUE_CLF_N_MELS, N_BINS,
                         (float)REPENIQUE_CLF_SR, 40.0f, 12000.0f);
    return st;
}

void repenique_classifier_free(repenique_classifier_state* state) {
    if (!state) return;
    if (state->fft_cfg) free(state->fft_cfg);
    free(state);
}

int repenique_classifier_mel_spec(repenique_classifier_state* state,
                                   const float* audio,
                                   float* mel_out) {
    if (!state)   return -1;
    if (!audio)   return -2;
    if (!mel_out) return -3;
    /* This API requires fixed window of WIN_SAMPLES (4410) */

    const int n = REPENIQUE_CLF_WIN_SAMPLES;
    const int n_fft = REPENIQUE_CLF_N_FFT;
    const int hop = REPENIQUE_CLF_HOP;
    const int pad = n_fft / 2;
    const int n_mels = REPENIQUE_CLF_N_MELS;
    const int n_bins = N_BINS;
    const int target_frames = REPENIQUE_CLF_WIN_FRAMES;

    /* Reflect padding (matching torchaudio center=True) */
    reflect_pad(audio, n, pad, state->padded);
    const int padded_len = n + n_fft;
    const int n_frames = 1 + (padded_len - n_fft) / hop;
    /* Use min(n_frames, target_frames) and zero-pad the rest */

    /* For each frame: window → FFT → power → mel */
    for (int f = 0; f < target_frames; ++f) {
        if (f >= n_frames) {
            /* zero-pad mel column */
            for (int m = 0; m < n_mels; ++m) {
                mel_out[m * target_frames + f] = 0.0f;
            }
            continue;
        }
        const float* src = state->padded + f * hop;
        for (int i = 0; i < n_fft; ++i) {
            state->frame_buf[i] = src[i] * state->hann[i];
        }
        kiss_fftr(state->fft_cfg, state->frame_buf, state->cpx_out);
        /* power = |fft|^2 */
        for (int b = 0; b < n_bins; ++b) {
            float r = state->cpx_out[b].r;
            float i = state->cpx_out[b].i;
            state->power_col[b] = r * r + i * i;
        }
        /* mel filterbank */
        for (int m = 0; m < n_mels; ++m) {
            const float* fb_row = state->mel_fb + m * n_bins;
            float acc = 0.0f;
            for (int b = 0; b < n_bins; ++b) {
                acc += fb_row[b] * state->power_col[b];
            }
            mel_out[m * target_frames + f] = acc;
        }
    }

    /* log10(mel + 1e-6) + per-sample normalize (mean/std) */
    const int total = n_mels * target_frames;
    float sum = 0.0f;
    for (int i = 0; i < total; ++i) {
        mel_out[i] = log10f(mel_out[i] + 1e-6f);
        sum += mel_out[i];
    }
    float mean = sum / (float)total;
    float var = 0.0f;
    for (int i = 0; i < total; ++i) {
        float d = mel_out[i] - mean;
        var += d * d;
    }
    float std = sqrtf(var / (float)total) + 1e-6f;
    for (int i = 0; i < total; ++i) {
        mel_out[i] = (mel_out[i] - mean) / std;
    }
    return 0;
}

int repenique_pick_peaks(const float* envelope, int32_t n_frames,
                          float threshold, int32_t min_distance_frames,
                          int32_t* peaks_out, int32_t peaks_capacity) {
    if (!envelope)   return -1;
    if (!peaks_out)  return -2;
    if (n_frames < 3 || min_distance_frames < 1) return -3;

    /* Step 1: collect all local maxima above threshold.
     * Local max: envelope[i] > envelope[i-1] AND envelope[i] >= envelope[i+1].
     * (Plateau handling: keep left edge of plateau.) */
    std::vector<int32_t> candidates;
    candidates.reserve((size_t)n_frames / 4 + 1);
    for (int32_t i = 1; i < n_frames - 1; ++i) {
        if (envelope[i] < threshold) continue;
        if (envelope[i] <= envelope[i - 1]) continue;
        if (envelope[i] < envelope[i + 1]) continue;
        candidates.push_back(i);
    }
    if (candidates.empty()) return 0;

    /* Step 2: sort by HEIGHT descending (matches scipy.signal.find_peaks
     * tie-breaking — highest peak wins when within min_distance). */
    std::sort(candidates.begin(), candidates.end(),
              [envelope](int32_t a, int32_t b) {
                  return envelope[a] > envelope[b];
              });

    /* Step 3: greedy from highest — accept if not within min_distance of any
     * already-accepted peak. */
    std::vector<int32_t> accepted;
    accepted.reserve(candidates.size());
    for (int32_t c : candidates) {
        bool conflict = false;
        for (int32_t a : accepted) {
            int32_t diff = c > a ? c - a : a - c;
            if (diff < min_distance_frames) { conflict = true; break; }
        }
        if (!conflict) accepted.push_back(c);
    }

    /* Step 4: sort accepted ascending (output is sorted by time) */
    std::sort(accepted.begin(), accepted.end());

    int32_t n_to_write = (int32_t)accepted.size();
    if (n_to_write > peaks_capacity) {
        for (int32_t i = 0; i < peaks_capacity; ++i)
            peaks_out[i] = accepted[i];
        return -4;
    }
    for (int32_t i = 0; i < n_to_write; ++i)
        peaks_out[i] = accepted[i];
    return n_to_write;
}
