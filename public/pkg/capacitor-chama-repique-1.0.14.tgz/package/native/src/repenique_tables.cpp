/**
 * Construção de tabelas fixas (hann, mel, dct, sc_freq, sc_bands) e gestão de scratch buffers.
 *
 * Port 1:1 das funções _build_mel_basis, _build_dct_basis de train_chamadas.py.
 * Optimizado com mel filterbank esparso e spectral contrast pré-computado.
 */

#include "repenique_tables.h"
#include <cmath>
#include <cstdlib>
#include <cstring>
#include <algorithm>

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

/* --- Mel scale (Slaney / auditory toolbox) --- */

static double mel_hz(double hz) {
    const double f_sp = 200.0 / 3.0;
    const double min_log_hz = 1000.0;
    const double min_log_mel = min_log_hz / f_sp;
    const double logstep = log(6.4) / 27.0;
    if (hz >= min_log_hz)
        return min_log_mel + log(std::max(hz, 1e-18)) / logstep - log(min_log_hz) / logstep;
    return hz / f_sp;
}

static double mel_inv(double mel) {
    const double f_sp = 200.0 / 3.0;
    const double min_log_hz = 1000.0;
    const double min_log_mel = min_log_hz / f_sp;
    const double logstep = log(6.4) / 27.0;
    if (mel >= min_log_mel)
        return min_log_hz * exp(logstep * (mel - min_log_mel));
    return mel * f_sp;
}

/* Banker's rounding (round half to even) */
static double bankers_round(double x) {
    double frac = x - floor(x);
    if (frac > 0.5) return ceil(x);
    if (frac < 0.5) return floor(x);
    double lo = floor(x);
    return (fmod(lo, 2.0) == 0.0) ? lo : ceil(x);
}

/* --- Mel filterbank builder (shared by Dense and CNN) --- */

static void build_mel_filterbank(double fmin, double fmax,
                                  float* dense_buf,
                                  mel_sparse_row* sparse) {
    double mel_min = mel_hz(fmin);
    double mel_max = mel_hz(fmax);
    double mels[N_MELS + 2];
    for (int i = 0; i <= N_MELS + 1; ++i) {
        mels[i] = mel_min + (mel_max - mel_min) * i / (N_MELS + 1);
    }
    double freqs[N_MELS + 2];
    for (int i = 0; i <= N_MELS + 1; ++i) {
        freqs[i] = mel_inv(mels[i]);
    }
    double fft_freqs[N_BINS];
    for (int i = 0; i < N_BINS; ++i) {
        fft_freqs[i] = (double)SAMPLE_RATE * i / N_FFT;
    }
    double fdiff[N_MELS + 1];
    for (int i = 0; i <= N_MELS; ++i) {
        fdiff[i] = freqs[i + 1] - freqs[i];
    }

    std::memset(dense_buf, 0, sizeof(float) * N_MELS * N_BINS);

    for (int i = 0; i < N_MELS; ++i) {
        double enorm = 2.0 / (freqs[i + 2] - freqs[i]);
        float* row = dense_buf + i * N_BINS;

        for (int j = 0; j < N_BINS; ++j) {
            double lower_slope = (fft_freqs[j] - freqs[i]) / (fdiff[i] + 1e-18);
            double upper_slope = (freqs[i + 2] - fft_freqs[j]) / (fdiff[i + 1] + 1e-18);
            double w = std::max(0.0, std::min(lower_slope, upper_slope));
            row[j] = (float)(w * enorm);
        }

        /* Build sparse row: find first/last nonzero */
        int first_nz = -1, last_nz = -1;
        for (int j = 0; j < N_BINS; ++j) {
            if (row[j] != 0.0f) {
                if (first_nz < 0) first_nz = j;
                last_nz = j;
            }
        }
        if (first_nz >= 0) {
            int len = last_nz - first_nz + 1;
            sparse[i].start = first_nz;
            sparse[i].len = len;
            sparse[i].weights = (float*)malloc(sizeof(float) * len);
            std::memcpy(sparse[i].weights, row + first_nz, sizeof(float) * len);
        } else {
            sparse[i].start = 0;
            sparse[i].len = 0;
            sparse[i].weights = nullptr;
        }
    }
}

/* --- Table builders --- */

void repenique_build_tables(repenique_state* state) {
    /* 1. Hann window (periodic): 0.5 - 0.5·cos(2π·n/N) */
    for (int n = 0; n < N_FFT; ++n) {
        state->hann[n] = (float)(0.5 - 0.5 * cos(2.0 * M_PI * n / N_FFT));
    }

    /* 2a. Mel filterbank — Dense (fmin=0, fmax=22050) */
    build_mel_filterbank(0.0, (double)SAMPLE_RATE / 2.0,
                         state->mel_basis, state->mel_sparse);

    /* 2b. Mel filterbank — CNN (fmin=40, fmax=8000) */
    build_mel_filterbank((double)CNN_FMIN, (double)CNN_FMAX,
                         state->mel_basis_cnn, state->mel_sparse_cnn);

    /* 3. DCT-II ortho basis (20 × 128) */
    {
        for (int k = 0; k < N_MFCC; ++k) {
            for (int n = 0; n < N_MELS; ++n) {
                state->dct_basis[k * N_MELS + n] =
                    cos(M_PI * k * (2.0 * n + 1.0) / (2.0 * N_MELS));
            }
        }
        double scale0 = sqrt(1.0 / N_MELS);
        for (int n = 0; n < N_MELS; ++n) {
            state->dct_basis[n] *= scale0;
        }
        double scale1 = sqrt(2.0 / N_MELS);
        for (int k = 1; k < N_MFCC; ++k) {
            for (int n = 0; n < N_MELS; ++n) {
                state->dct_basis[k * N_MELS + n] *= scale1;
            }
        }
    }

    /* 4. Spectral contrast frequencies + precomputed band descriptors */
    for (int i = 0; i < N_BINS; ++i) {
        state->sc_freq[i] = (double)SAMPLE_RATE * i / N_FFT;
    }

    {
        /* octa = [0, 200, 400, 800, 1600, 3200, 6400, 12800] */
        double octa[SC_N_BANDS + 2];
        octa[0] = 0.0;
        for (int i = 0; i <= SC_N_BANDS; ++i) {
            octa[i + 1] = SC_FMIN * pow(2.0, i);
        }

        for (int k = 0; k < SC_N_BANDS_TOTAL; ++k) {
            double f_low  = octa[k];
            double f_high = octa[k + 1];

            int idx_first = -1, idx_last = -1;
            for (int b = 0; b < N_BINS; ++b) {
                if (state->sc_freq[b] >= f_low && state->sc_freq[b] <= f_high) {
                    if (idx_first < 0) idx_first = b;
                    idx_last = b;
                }
            }
            if (idx_first < 0) {
                state->sc_bands[k] = {0, 0, 1};
                continue;
            }

            int band_start = idx_first;
            int band_end   = idx_last;

            if (k > 0 && band_start > 0) band_start -= 1;
            if (k == SC_N_BANDS && band_end + 1 < N_BINS) band_end = N_BINS - 1;

            int band_len = band_end - band_start + 1;
            int sub_len = band_len;
            if (k < SC_N_BANDS && sub_len > 1) sub_len -= 1;

            int q_idx = (int)std::max(bankers_round(SC_QUANTILE * band_len), 1.0);

            state->sc_bands[k].band_start = band_start;
            state->sc_bands[k].sub_len    = sub_len;
            state->sc_bands[k].q_idx      = q_idx;
        }
    }
}


int repenique_ensure_scratch(repenique_state* state,
                             int32_t n_frames, int32_t padded_len) {
    /* Padded audio buffer */
    if (padded_len > state->padded_cap) {
        float* p = (float*)realloc(state->padded, sizeof(float) * padded_len);
        if (!p) return -5;
        state->padded = p;
        state->padded_cap = padded_len;
    }

    /* Frame-based buffers */
    if (n_frames > state->frame_cap) {
        float* sm = (float*)realloc(state->stft_mag,  sizeof(float) * N_BINS * n_frames);
        float* ms = (float*)realloc(state->mel_spec,  sizeof(float) * N_MELS * n_frames);
        float* md = (float*)realloc(state->mel_db,    sizeof(float) * N_MELS * n_frames);
        float* oe = (float*)realloc(state->onset_env, sizeof(float) * n_frames);
        if (!sm || !ms || !md || !oe) {
            if (sm) state->stft_mag  = sm;
            if (ms) state->mel_spec  = ms;
            if (md) state->mel_db    = md;
            if (oe) state->onset_env = oe;
            return -5;
        }
        state->stft_mag  = sm;
        state->mel_spec  = ms;
        state->mel_db    = md;
        state->onset_env = oe;
        state->frame_cap = n_frames;
    }

    /* Sort buffer (allocated once, N_BINS is fixed) */
    if (!state->sort_buf) {
        state->sort_buf = (float*)malloc(sizeof(float) * N_BINS);
        if (!state->sort_buf) return -5;
    }

    /* Onset scratch: need 2*n_frames ints + ~4*n_frames doubles */
    int32_t need_ints = 3 * n_frames + 2;  /* onset_bt + onset_no_bt + minima */
    if (need_ints > state->onset_buf_cap) {
        int* p = (int*)realloc(state->onset_buf, sizeof(int) * need_ints);
        if (!p) return -5;
        state->onset_buf = p;
        state->onset_buf_cap = need_ints;
    }
    /* SC needs 14*n_frames (peak_db + valley_db, 7 bands each)
     * onset needs 4*n_frames (env_norm + onset_times + iois + iois_sorted)
     * SC runs first, so same buffer is reused for onset afterwards. */
    int32_t need_doubles = 14 * n_frames;  /* max(14*n_frames for SC, 4*n_frames for onset) */
    if (need_doubles > state->onset_dbuf_cap) {
        double* p = (double*)realloc(state->onset_dbuf, sizeof(double) * need_doubles);
        if (!p) return -5;
        state->onset_dbuf = p;
        state->onset_dbuf_cap = need_doubles;
    }

    return 0;
}
