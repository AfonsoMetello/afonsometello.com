/**
 * Internal tables and scratch buffers for repenique_dsp.
 *
 * Constantes (SAMPLE_RATE, N_FFT, etc.) replicam src/__init__.py.
 */

#ifndef REPENIQUE_TABLES_H
#define REPENIQUE_TABLES_H

#include <stdint.h>
#include "kiss_fftr.h"

/* Audio/DSP constants (mirror src/__init__.py + train_chamadas.py) */
static const int    SAMPLE_RATE     = 44100;
static const int    N_FFT           = 2048;
static const int    HOP_LENGTH      = 512;
static const int    N_MELS          = 128;
static const int    N_MFCC          = 20;
static const int    N_BINS          = N_FFT / 2 + 1;  /* 1025 */
static const float  TARGET_RMS      = 0.1f;
static const int    N_FEATURES      = 84;

/* CNN preprocessing constants */
static const float  CNN_FMIN        = 40.0f;
static const float  CNN_FMAX        = 8000.0f;
static const int    CNN_TARGET_SAMPLES = 154350;  /* int(3.5 * 44100) */
static const int    CNN_TARGET_FRAMES  = 302;     /* ceil(3.5 * 44100 / 512) */
static const int    CNN_MEL_SIZE       = N_MELS * CNN_TARGET_FRAMES;  /* 38656 */

/* Attention preprocessing constants */
static const int    ATT_MAX_FRAMES     = 736;     /* ~8.55s */
static const int    ATT_MAX_SAMPLES    = 376740;  /* ATT_MAX_FRAMES * HOP_LENGTH */
static const int    ATT_MEL_SIZE       = N_MELS * ATT_MAX_FRAMES;  /* 93888 */

/* Spectral contrast constants */
static const int    SC_N_BANDS      = 6;
static const int    SC_N_BANDS_TOTAL = SC_N_BANDS + 1;  /* 7 output bands */
static const float  SC_FMIN         = 200.0f;
static const float  SC_QUANTILE     = 0.02f;

/* Sparse mel row: only nonzero range of each triangular filter */
struct mel_sparse_row {
    int start;      /* first nonzero bin index */
    int len;        /* number of nonzero weights */
    float* weights; /* nonzero values (allocated in init) */
};

/* Precomputed spectral contrast band descriptor */
struct sc_band_desc {
    int band_start;  /* first bin (inclusive) */
    int sub_len;     /* bins to use for sorting (after removing last bin for non-last) */
    int q_idx;       /* quantile index (>= 1) */
};

struct repenique_state {
    /* KissFFT real-FFT plan (2048-pt) */
    kiss_fftr_cfg fft_cfg;

    /* Fixed tables (built once in init) */
    float  hann[N_FFT];                 /* Hann window (2048) */
    float  mel_basis[N_MELS * N_BINS];  /* row-major (128 × 1025) — Dense (fmin=0, fmax=22050) */
    mel_sparse_row mel_sparse[N_MELS];  /* sparse version (only nonzero ranges) */
    float  mel_basis_cnn[N_MELS * N_BINS];  /* row-major (128 × 1025) — CNN (fmin=40, fmax=8000) */
    mel_sparse_row mel_sparse_cnn[N_MELS];  /* sparse CNN version */
    double dct_basis[N_MFCC * N_MELS];  /* row-major (20 × 128) */
    double sc_freq[N_BINS];             /* FFT bin frequencies (1025) */
    sc_band_desc sc_bands[SC_N_BANDS_TOTAL]; /* precomputed band descriptors */

    /* Scratch buffers (re-allocated when n_frames > frame_cap) */
    float*  padded;      /* center-padded audio (also used for RMS normalization) */
    int32_t padded_cap;  /* capacity in samples */

    float*  stft_mag;    /* |STFT|   (N_BINS × n_frames), col-major */
    float*  mel_spec;    /* mel spectrogram (N_MELS × n_frames), col-major */
    float*  mel_db;      /* mel dB (N_MELS × n_frames), col-major */
    float*  onset_env;   /* onset envelope (n_frames) */
    float*  sort_buf;    /* temp buffer for spectral contrast sort (N_BINS) */

    /* Scratch for onset features (avoid malloc per call) */
    int*    onset_buf;   /* shared buffer for onset frames (2 × max_onsets + n_frames) */
    double* onset_dbuf;  /* shared double buffer for env_norm, onset_times, iois, etc. */
    int32_t onset_buf_cap;
    int32_t onset_dbuf_cap;

    int32_t frame_cap;   /* current capacity in frames */

    /* CNN scratch buffer (preprocessed audio: trimmed + RMS-normalized + padded) */
    float*  cnn_buf;     /* CNN_TARGET_SAMPLES floats (allocated lazily) */
    int32_t cnn_buf_cap;
};

/**
 * Build all fixed tables in state (hann, mel_basis+sparse, dct_basis, sc_freq, sc_bands).
 * Called once from repenique_init().
 */
void repenique_build_tables(repenique_state* state);

/**
 * Ensure scratch buffers can hold n_frames. Re-allocates if needed.
 * Also ensures padded buffer can hold padded_len samples.
 * Returns 0=ok, -5=alloc fail.
 */
int repenique_ensure_scratch(repenique_state* state,
                             int32_t n_frames, int32_t padded_len);

#endif /* REPENIQUE_TABLES_H */
