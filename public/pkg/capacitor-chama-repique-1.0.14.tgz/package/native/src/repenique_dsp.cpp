/**
 * Repenique DSP — Extração de 84 features para classificação de chamadas.
 *
 * Port de _extract_features_tuned_numpy() (train_chamadas.py).
 * Usa KissFFT para STFT. Sem STL/exceptions na interface pública.
 *
 * Optimizações vs v1.0.0:
 *   - Mel filterbank esparso (~97% zeros eliminados, ~20x menos FLOPs)
 *   - Fusão mel_spec no loop STFT (dados ficam hot em L1, stft_pow eliminado)
 *   - std::nth_element em vez de qsort no spectral contrast (O(N) vs O(N log N))
 *   - Todos os mallocs movidos para scratch buffers no state (zero allocs por call)
 *   - Spectral contrast band descriptors pré-computados no init
 */

#include "repenique_dsp.h"
#include "repenique_tables.h"

#include <cmath>
#include <cstdlib>
#include <cstring>
#include <algorithm>
#include <cfloat>

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

#define VERSION_STR "2.0.0"


/* ====================================================================== */
/* power_to_db: 10·log10(max(S, 1e-10)) — clip top_db=80                 */
/* ====================================================================== */

static void power_to_db(const float* S, float* out, int n,
                        float ref, float amin, float top_db) {
    float log_ref = 10.0f * log10f(std::max(ref, amin));
    float max_val = -FLT_MAX;
    for (int i = 0; i < n; ++i) {
        out[i] = 10.0f * log10f(std::max(S[i], amin)) - log_ref;
        if (out[i] > max_val) max_val = out[i];
    }
    if (top_db > 0.0f) {
        float floor_val = max_val - top_db;
        for (int i = 0; i < n; ++i) {
            if (out[i] < floor_val) out[i] = floor_val;
        }
    }
}

static inline float single_power_to_db(float val) {
    return 10.0f * log10f(std::max(val, 1e-10f));
}


/* ====================================================================== */
/* Fused STFT + sparse mel: per frame, compute FFT → mag → sparse mel     */
/* Elimina stft_pow inteiramente; mel_spec é escrito enquanto dados       */
/* estão hot em L1.                                                       */
/* ====================================================================== */

static void compute_stft_and_mel(repenique_state* st,
                                 const float* audio, int32_t n_samples,
                                 float rms_scale,
                                 const mel_sparse_row* mel_rows,
                                 int32_t* out_n_frames) {
    const int pad = N_FFT / 2;
    const int32_t padded_len = n_samples + N_FFT;
    std::memset(st->padded, 0, sizeof(float) * padded_len);
    std::memcpy(st->padded + pad, audio, sizeof(float) * n_samples);

    const int32_t n_frames = 1 + (padded_len - N_FFT) / HOP_LENGTH;
    *out_n_frames = n_frames;

    float frame_buf[N_FFT];
    kiss_fft_cpx cpx_out[N_BINS];
    float pow_col[N_BINS];

    for (int32_t f = 0; f < n_frames; ++f) {
        const float* src = st->padded + f * HOP_LENGTH;

        /* Hann window + RMS scale fused (zero extra cost) */
        for (int i = 0; i < N_FFT; ++i) {
            frame_buf[i] = src[i] * st->hann[i] * rms_scale;
        }

        /* FFT → magnitude + power */
        kiss_fftr(st->fft_cfg, frame_buf, cpx_out);

        float* mag_col = st->stft_mag + f * N_BINS;
        for (int b = 0; b < N_BINS; ++b) {
            float re = cpx_out[b].r;
            float im = cpx_out[b].i;
            float mag = sqrtf(re * re + im * im);
            mag_col[b] = mag;
            pow_col[b] = mag * mag;
        }

        /* Sparse mel: mel_spec[:, f] = mel_sparse @ pow_col */
        float* mel_col = st->mel_spec + f * N_MELS;
        for (int m = 0; m < N_MELS; ++m) {
            const mel_sparse_row& row = mel_rows[m];
            if (row.len == 0) {
                mel_col[m] = 0.0f;
                continue;
            }
            float sum = 0.0f;
            const float* w = row.weights;
            const float* p = pow_col + row.start;
            for (int i = 0; i < row.len; ++i) {
                sum += w[i] * p[i];
            }
            mel_col[m] = sum;
        }
    }
}


/* ====================================================================== */
/* mel_db: power_to_db applied to mel_spec                                */
/* ====================================================================== */

static void compute_mel_db(repenique_state* st, int32_t n_frames) {
    power_to_db(st->mel_spec, st->mel_db, N_MELS * n_frames,
                1.0f, 1e-10f, 80.0f);
}


/* ====================================================================== */
/* MFCC mean: dct_basis @ mel_db → mean over frames → (20,)              */
/* ====================================================================== */

static void compute_mfcc_mean(repenique_state* st, int32_t n_frames,
                              float* out20) {
    for (int k = 0; k < N_MFCC; ++k) {
        double sum_all = 0.0;
        const double* dct_row = st->dct_basis + k * N_MELS;
        for (int32_t f = 0; f < n_frames; ++f) {
            const float* db_col = st->mel_db + f * N_MELS;
            double dot = 0.0;
            for (int m = 0; m < N_MELS; ++m) {
                dot += dct_row[m] * (double)db_col[m];
            }
            sum_all += dot;
        }
        out20[k] = (float)(sum_all / n_frames);
    }
}


/* ====================================================================== */
/* Spectral contrast: nth_element + precomputed bands                     */
/* ====================================================================== */

static void compute_spectral_contrast_mean(repenique_state* st,
                                           int32_t n_frames,
                                           float* out7) {
    float* sort_buf = st->sort_buf;

    /* Use onset_dbuf as scratch (SC runs before onset detection).
     * Layout: peak_db[7 * n_frames] + valley_db[7 * n_frames] */
    double* peak_db   = st->onset_dbuf;
    double* valley_db = st->onset_dbuf + SC_N_BANDS_TOTAL * n_frames;

    for (int k = 0; k < SC_N_BANDS_TOTAL; ++k) {
        const sc_band_desc& bd = st->sc_bands[k];
        if (bd.sub_len == 0) {
            for (int32_t f = 0; f < n_frames; ++f) {
                peak_db  [k * n_frames + f] = single_power_to_db(1e-10f);
                valley_db[k * n_frames + f] = single_power_to_db(1e-10f);
            }
            continue;
        }

        int sub_len = bd.sub_len;
        int q_idx   = bd.q_idx;
        int vn = std::min(q_idx, sub_len);
        int pn = std::min(q_idx, sub_len);

        for (int32_t f = 0; f < n_frames; ++f) {
            const float* mag_col = st->stft_mag + f * N_BINS;

            std::memcpy(sort_buf, mag_col + bd.band_start, sizeof(float) * sub_len);

            /* nth_element for valley (smallest vn): O(N) average */
            if (vn < sub_len) {
                std::nth_element(sort_buf, sort_buf + vn, sort_buf + sub_len);
            }
            float v = 0.0f;
            for (int i = 0; i < vn; ++i) v += sort_buf[i];
            v /= vn;

            /* nth_element for peak (largest pn): O(N) average */
            if (pn < sub_len) {
                std::nth_element(sort_buf, sort_buf + sub_len - pn, sort_buf + sub_len);
            }
            float p = 0.0f;
            for (int i = sub_len - pn; i < sub_len; ++i) p += sort_buf[i];
            p /= pn;

            peak_db  [k * n_frames + f] = (double)single_power_to_db(p);
            valley_db[k * n_frames + f] = (double)single_power_to_db(v);
        }
    }

    /* top_db=80 clipping (matches librosa/numpy _power_to_db_np).
     * Global max computed separately for peaks and valleys,
     * across ALL bands and frames. */
    const double TOP_DB = 80.0;
    int total = SC_N_BANDS_TOTAL * n_frames;

    double peak_max = -1e30;
    for (int i = 0; i < total; ++i)
        if (peak_db[i] > peak_max) peak_max = peak_db[i];
    double peak_floor = peak_max - TOP_DB;
    for (int i = 0; i < total; ++i)
        if (peak_db[i] < peak_floor) peak_db[i] = peak_floor;

    double valley_max = -1e30;
    for (int i = 0; i < total; ++i)
        if (valley_db[i] > valley_max) valley_max = valley_db[i];
    double valley_floor = valley_max - TOP_DB;
    for (int i = 0; i < total; ++i)
        if (valley_db[i] < valley_floor) valley_db[i] = valley_floor;

    /* Compute mean contrast per band */
    for (int k = 0; k < SC_N_BANDS_TOTAL; ++k) {
        double c_sum = 0.0;
        for (int32_t f = 0; f < n_frames; ++f) {
            c_sum += peak_db[k * n_frames + f] - valley_db[k * n_frames + f];
        }
        out7[k] = (float)(c_sum / n_frames);
    }
}


/* ====================================================================== */
/* Onset envelope: mel→dB→diff→HWR→mean→pad 3 zeros                      */
/* ====================================================================== */

static void compute_onset_envelope(repenique_state* st, int32_t n_frames) {
    const int pad_width = 1 + N_FFT / (2 * HOP_LENGTH);  /* = 3 */

    std::memset(st->onset_env, 0, sizeof(float) * n_frames);
    if (n_frames < 2) return;

    int n_output = std::min(n_frames - 1, n_frames - pad_width);

    for (int d = 0; d < n_output; ++d) {
        const float* col_prev = st->mel_db + d * N_MELS;
        const float* col_next = st->mel_db + (d + 1) * N_MELS;
        float sum = 0.0f;
        for (int m = 0; m < N_MELS; ++m) {
            float diff = col_next[m] - col_prev[m];
            if (diff > 0.0f) sum += diff;
        }
        st->onset_env[pad_width + d] = sum / N_MELS;
    }
}


/* ====================================================================== */
/* Peak pick + onset detect (uses pre-allocated scratch buffers)          */
/* ====================================================================== */

static int peak_pick(const double* x, int n,
                     int pre_max, int post_max,
                     int pre_avg, int post_avg,
                     double delta, int wait,
                     int* peaks, int max_peaks) {
    if (n == 0) return 0;
    int n_peaks = 0;

    /* Frame 0 */
    {
        double maxv = x[0];
        for (int i = 1; i < std::min(post_max, n); ++i)
            if (x[i] > maxv) maxv = x[i];
        double sum = 0.0;
        int cnt = std::min(post_avg, n);
        for (int i = 0; i < cnt; ++i) sum += x[i];
        if (x[0] >= maxv && x[0] >= sum / cnt + delta)
            if (n_peaks < max_peaks) peaks[n_peaks++] = 0;
    }

    int idx = (n_peaks > 0) ? (wait + 1) : 1;
    while (idx < n) {
        int lo = std::max(0, idx - pre_max);
        int hi = std::min(idx + post_max, n);
        double maxv = x[lo];
        for (int i = lo + 1; i < hi; ++i)
            if (x[i] > maxv) maxv = x[i];
        if (x[idx] != maxv) { ++idx; continue; }

        lo = std::max(0, idx - pre_avg);
        hi = std::min(idx + post_avg, n);
        double sum = 0.0;
        for (int i = lo; i < hi; ++i) sum += x[i];
        if (x[idx] < sum / (hi - lo) + delta) { ++idx; continue; }

        if (n_peaks < max_peaks) peaks[n_peaks++] = idx;
        idx += wait + 1;
    }
    return n_peaks;
}

/* Onset detect using pre-allocated buffers from state */
static int onset_detect(const float* env, int n_frames, bool backtrack,
                        double* env_norm,   /* pre-allocated, n_frames doubles */
                        int* minima_buf,    /* pre-allocated, n_frames+1 ints */
                        int* onsets, int max_onsets) {
    if (n_frames < 2) return 0;

    bool any_nonzero = false;
    for (int i = 0; i < n_frames; ++i) {
        if (!std::isfinite(env[i])) return 0;
        if (env[i] != 0.0f) any_nonzero = true;
    }
    if (!any_nonzero) return 0;

    /* Normalize to [0, 1] */
    double env_min = (double)env[0];
    for (int i = 1; i < n_frames; ++i)
        if ((double)env[i] < env_min) env_min = (double)env[i];
    double env_max = 0.0;
    for (int i = 0; i < n_frames; ++i) {
        env_norm[i] = (double)env[i] - env_min;
        if (env_norm[i] > env_max) env_max = env_norm[i];
    }
    if (env_max > 0.0) {
        double tiny = 2.2204460492503131e-16;
        for (int i = 0; i < n_frames; ++i)
            env_norm[i] /= (env_max + tiny);
    }

    /* Peak pick */
    int pre_max  = (int)(0.03 * SAMPLE_RATE / HOP_LENGTH);
    int post_max = (int)(0.00 * SAMPLE_RATE / HOP_LENGTH) + 1;
    int pre_avg  = (int)(0.10 * SAMPLE_RATE / HOP_LENGTH);
    int post_avg = (int)(0.10 * SAMPLE_RATE / HOP_LENGTH) + 1;
    int wait     = (int)(0.03 * SAMPLE_RATE / HOP_LENGTH);

    int n_onsets = peak_pick(env_norm, n_frames,
                             pre_max, post_max, pre_avg, post_avg,
                             0.07, wait, onsets, max_onsets);

    if (backtrack && n_onsets > 0) {
        int n_minima = 0;
        minima_buf[n_minima++] = 0;
        for (int i = 1; i < n_frames - 1; ++i) {
            if (env_norm[i] <= env_norm[i - 1] && env_norm[i] < env_norm[i + 1])
                minima_buf[n_minima++] = i;
        }
        for (int j = 0; j < n_onsets; ++j) {
            int oi = onsets[j];
            int best = 0;
            for (int m = 0; m < n_minima; ++m) {
                if (minima_buf[m] <= oi) best = minima_buf[m];
                else break;
            }
            onsets[j] = best;
        }
    }

    return n_onsets;
}


/* ====================================================================== */
/* Main: repenique_extract (84 features)                                  */
/* ====================================================================== */

int repenique_extract(repenique_state* state,
                      const float* audio, int32_t n_samples,
                      float* out) {
    if (!state)  return -1;
    if (!audio)  return -2;
    if (!out)    return -3;
    if (n_samples < N_FFT) return -4;

    const int32_t padded_len = n_samples + N_FFT;
    const int32_t n_frames = 1 + (padded_len - N_FFT) / HOP_LENGTH;

    int rc = repenique_ensure_scratch(state, n_frames, padded_len);
    if (rc != 0) return rc;

    /* RMS normalize — compute scale factor, applied inside STFT windowing */
    float rms_val = 0.0f;
    for (int32_t i = 0; i < n_samples; ++i)
        rms_val += audio[i] * audio[i];
    rms_val = sqrtf(rms_val / n_samples);
    float rms_scale = (rms_val > 1e-8f) ? (TARGET_RMS / rms_val) : 1.0f;

    /* Fused STFT + sparse mel (RMS scale applied during windowing) */
    int32_t actual_frames = 0;
    compute_stft_and_mel(state, audio, n_samples, rms_scale,
                         state->mel_sparse, &actual_frames);

    /* mel_db */
    compute_mel_db(state, actual_frames);

    int fi = 0;

    /* [0:20] MFCC mean */
    compute_mfcc_mean(state, actual_frames, out + fi);
    fi += N_MFCC;

    /* [20:27] Spectral contrast mean */
    compute_spectral_contrast_mean(state, actual_frames, out + fi);
    fi += 7;

    /* Onset envelope */
    compute_onset_envelope(state, actual_frames);
    const float* onset_env = state->onset_env;

    /* [27:29] onset env stats */
    {
        double sum = 0.0, sum2 = 0.0;
        for (int32_t i = 0; i < actual_frames; ++i) {
            double v = (double)onset_env[i];
            sum += v;
            sum2 += v * v;
        }
        double mean = sum / actual_frames;
        double var = sum2 / actual_frames - mean * mean;
        if (var < 0.0) var = 0.0;
        out[fi++] = (float)mean;
        out[fi++] = (float)sqrt(var);
    }

    /* [29:49] Autocorrelation (20 lags) */
    {
        const int n_lags = 20;
        if (actual_frames > 1) {
            double mean = 0.0;
            for (int32_t i = 0; i < actual_frames; ++i)
                mean += (double)onset_env[i];
            mean /= actual_frames;

            double autocorr0 = 0.0;
            for (int32_t i = 0; i < actual_frames; ++i) {
                double v = (double)onset_env[i] - mean;
                autocorr0 += v * v;
            }

            if (autocorr0 > 0.0) {
                out[fi++] = 1.0f;
                for (int lag = 1; lag < n_lags; ++lag) {
                    if (lag < actual_frames) {
                        double ac = 0.0;
                        for (int32_t i = 0; i < actual_frames - lag; ++i) {
                            double vi = (double)onset_env[i] - mean;
                            double vj = (double)onset_env[i + lag] - mean;
                            ac += vi * vj;
                        }
                        out[fi++] = (float)(ac / autocorr0);
                    } else {
                        out[fi++] = 0.0f;
                    }
                }
            } else {
                for (int i = 0; i < n_lags; ++i) out[fi++] = 0.0f;
            }
        } else {
            for (int i = 0; i < n_lags; ++i) out[fi++] = 0.0f;
        }
    }

    /* Onset detection — using pre-allocated scratch buffers */
    int* onset_frames_bt    = state->onset_buf;
    int* onset_frames_no_bt = state->onset_buf + actual_frames;
    int* minima_buf         = state->onset_buf + 2 * actual_frames;
    double* env_norm        = state->onset_dbuf;
    /* onset_times, iois, etc. share the rest of onset_dbuf */

    int n_onsets_bt = onset_detect(onset_env, actual_frames, true,
                                   env_norm, minima_buf,
                                   onset_frames_bt, actual_frames);
    int n_onsets_no_bt = onset_detect(onset_env, actual_frames, false,
                                      env_norm, minima_buf,
                                      onset_frames_no_bt, actual_frames);

    /* Onset times from backtracked frames — re-use env_norm area */
    double* onset_times = env_norm;  /* safe: onset_detect is done with env_norm */
    for (int i = 0; i < n_onsets_bt; ++i) {
        onset_times[i] = (double)onset_frames_bt[i] * HOP_LENGTH / (double)SAMPLE_RATE;
    }

    /* [49:50] onset_count */
    out[fi++] = (float)n_onsets_bt;

    /* IOI-based features */
    if (n_onsets_bt >= 2) {
        int n_iois = n_onsets_bt - 1;
        /* iois follow onset_times in the double buffer */
        double* iois = onset_times + n_onsets_bt;
        for (int i = 0; i < n_iois; ++i)
            iois[i] = onset_times[i + 1] - onset_times[i];

        /* Median via partial copy + sort */
        double* iois_sorted = iois + n_iois;
        std::memcpy(iois_sorted, iois, sizeof(double) * n_iois);
        std::sort(iois_sorted, iois_sorted + n_iois);
        double median_ioi;
        if (n_iois % 2 == 0)
            median_ioi = (iois_sorted[n_iois / 2 - 1] + iois_sorted[n_iois / 2]) / 2.0;
        else
            median_ioi = iois_sorted[n_iois / 2];

        if (median_ioi > 0.0) {
            /* Normalized IOIs — re-use iois_sorted area */
            double* iois_norm = iois_sorted;
            for (int i = 0; i < n_iois; ++i)
                iois_norm[i] = iois[i] / median_ioi;

            /* [50:54] ioi_stats */
            {
                double sum = 0.0, sum2 = 0.0;
                double mn = iois_norm[0], mx = iois_norm[0];
                for (int i = 0; i < n_iois; ++i) {
                    sum += iois_norm[i];
                    sum2 += iois_norm[i] * iois_norm[i];
                    if (iois_norm[i] < mn) mn = iois_norm[i];
                    if (iois_norm[i] > mx) mx = iois_norm[i];
                }
                double mean = sum / n_iois;
                double var = sum2 / n_iois - mean * mean;
                if (var < 0.0) var = 0.0;
                out[fi++] = (float)mean;
                out[fi++] = (float)sqrt(var);
                out[fi++] = (float)mn;
                out[fi++] = (float)mx;
            }

            /* [54:62] ioi_ratios */
            {
                const int n_ratios = 8;
                if (n_iois >= 2) {
                    for (int i = 0; i < n_ratios; ++i) {
                        if (i < n_iois - 1)
                            out[fi++] = (float)(iois_norm[i + 1] / (iois_norm[i] + 1e-8));
                        else
                            out[fi++] = 0.0f;
                    }
                } else {
                    for (int i = 0; i < n_ratios; ++i) out[fi++] = 0.0f;
                }
            }

            /* [62:72] ordered_iois */
            {
                const int n_ordered = 10;
                for (int i = 0; i < n_ordered; ++i)
                    out[fi++] = (i < n_iois) ? (float)iois_norm[i] : 0.0f;
            }

            /* [72:74] position_features */
            {
                int argmin = 0, argmax = 0;
                for (int i = 1; i < n_iois; ++i) {
                    if (iois_norm[i] < iois_norm[argmin]) argmin = i;
                    if (iois_norm[i] > iois_norm[argmax]) argmax = i;
                }
                double denom = (double)(n_iois - 1) + 1e-8;
                out[fi++] = (float)((double)argmin / denom);
                out[fi++] = (float)((double)argmax / denom);
            }
        } else {
            for (int i = 0; i < 24; ++i) out[fi++] = 0.0f;
        }
    } else {
        for (int i = 0; i < 24; ++i) out[fi++] = 0.0f;
    }

    /* [74:84] onset_strengths */
    {
        const int n_str = 10;
        if (n_onsets_no_bt > 0) {
            /* Use stack-local buffer (max 10 floats) */
            float strengths[10];
            int n_valid = 0;
            for (int i = 0; i < n_onsets_no_bt && n_valid < 10; ++i) {
                if (onset_frames_no_bt[i] < actual_frames)
                    strengths[n_valid++] = onset_env[onset_frames_no_bt[i]];
            }
            if (n_valid > 0) {
                float max_s = strengths[0];
                for (int i = 1; i < n_valid; ++i)
                    if (strengths[i] > max_s) max_s = strengths[i];
                if (max_s > 0.0f)
                    for (int i = 0; i < n_valid; ++i) strengths[i] /= max_s;
                for (int i = 0; i < n_str; ++i)
                    out[fi++] = (i < n_valid) ? strengths[i] : 0.0f;
            } else {
                for (int i = 0; i < n_str; ++i) out[fi++] = 0.0f;
            }
        } else {
            for (int i = 0; i < n_str; ++i) out[fi++] = 0.0f;
        }
    }

    return 0;
}


/* ====================================================================== */
/* CNN preprocessing: energy_trim → RMS norm → pad → STFT+mel → dB → z   */
/* ====================================================================== */

int repenique_preprocess_cnn(repenique_state* state,
                              const float* audio, int32_t n_samples,
                              float* mel_out) {
    if (!state)   return -1;
    if (!audio)   return -2;
    if (!mel_out) return -3;
    if (n_samples < 1) return -4;

    /* Ensure CNN scratch buffer */
    if (state->cnn_buf_cap < CNN_TARGET_SAMPLES) {
        float* p = (float*)realloc(state->cnn_buf,
                                    sizeof(float) * CNN_TARGET_SAMPLES);
        if (!p) return -5;
        state->cnn_buf = p;
        state->cnn_buf_cap = CNN_TARGET_SAMPLES;
    }

    /* --- Step 1: Energy trim --- */
    const int ETRIM_FRAME = (int)(0.03f * SAMPLE_RATE);  /* 1323 */
    int trim_start = 0;
    int trim_end = n_samples;

    if (n_samples > ETRIM_FRAME * 3) {
        int n_eframes = n_samples / ETRIM_FRAME;

        /* Compute per-frame RMS */
        float rms_buf[1024];
        float* frame_rms = rms_buf;
        bool heap_rms = false;
        if (n_eframes > 1024) {
            frame_rms = (float*)malloc(sizeof(float) * n_eframes);
            if (!frame_rms) return -5;
            heap_rms = true;
        }

        for (int i = 0; i < n_eframes; ++i) {
            const float* frm = audio + i * ETRIM_FRAME;
            float sum2 = 0.0f;
            for (int j = 0; j < ETRIM_FRAME; ++j)
                sum2 += frm[j] * frm[j];
            frame_rms[i] = sqrtf(sum2 / ETRIM_FRAME);
        }

        /* Noise floor: mean of bottom 20% frame RMS */
        float sorted_buf[1024];
        float* rms_sorted = sorted_buf;
        bool heap_sort = false;
        if (n_eframes > 1024) {
            rms_sorted = (float*)malloc(sizeof(float) * n_eframes);
            if (!rms_sorted) { if (heap_rms) free(frame_rms); return -5; }
            heap_sort = true;
        }
        std::memcpy(rms_sorted, frame_rms, sizeof(float) * n_eframes);
        std::sort(rms_sorted, rms_sorted + n_eframes);

        int n_bottom = std::max(1, n_eframes / 5);
        float noise_sum = 0.0f;
        for (int i = 0; i < n_bottom; ++i)
            noise_sum += rms_sorted[i];
        float noise_floor = noise_sum / n_bottom;
        float energy_thresh = std::max(noise_floor * 3.0f, 0.002f);

        if (heap_sort) free(rms_sorted);

        /* Find first/last active frame */
        int first_active = -1, last_active = -1;
        for (int i = 0; i < n_eframes; ++i) {
            if (frame_rms[i] > energy_thresh) {
                if (first_active < 0) first_active = i;
                last_active = i;
            }
        }

        if (heap_rms) free(frame_rms);

        if (first_active >= 0) {
            int start_frame = std::max(0, first_active - 1);
            int end_frame = std::min(n_eframes, last_active + 4);
            int new_start = start_frame * ETRIM_FRAME;
            int new_end = std::min(n_samples, end_frame * ETRIM_FRAME);
            if (new_start > 0 || new_end < n_samples) {
                trim_start = new_start;
                trim_end = new_end;
            }
        }
    }

    int trimmed_len = trim_end - trim_start;

    /* --- Step 2: RMS normalize (target=0.1) → cnn_buf --- */
    float rms_val = 0.0f;
    for (int i = 0; i < trimmed_len; ++i) {
        float v = audio[trim_start + i];
        rms_val += v * v;
    }
    rms_val = sqrtf(rms_val / trimmed_len);
    float rms_scale = (rms_val > 1e-8f) ? (TARGET_RMS / rms_val) : 1.0f;

    /* --- Step 3: Copy + normalize + pad/truncate to CNN_TARGET_SAMPLES --- */
    int copy_len = std::min(trimmed_len, (int)CNN_TARGET_SAMPLES);
    for (int i = 0; i < copy_len; ++i)
        state->cnn_buf[i] = audio[trim_start + i] * rms_scale;
    /* Zero-pad remainder */
    if (copy_len < CNN_TARGET_SAMPLES)
        std::memset(state->cnn_buf + copy_len, 0,
                    sizeof(float) * (CNN_TARGET_SAMPLES - copy_len));

    /* --- Step 4: STFT + sparse mel (CNN filterbank, rms_scale=1.0) --- */
    const int32_t padded_len = CNN_TARGET_SAMPLES + N_FFT;
    const int32_t n_frames_expected = 1 + (padded_len - N_FFT) / HOP_LENGTH;

    int rc = repenique_ensure_scratch(state, n_frames_expected, padded_len);
    if (rc != 0) return rc;

    int32_t n_frames = 0;
    compute_stft_and_mel(state, state->cnn_buf, CNN_TARGET_SAMPLES,
                         1.0f, state->mel_sparse_cnn, &n_frames);

    /* --- Step 5: power_to_db with ref=max(S) --- */
    int total = N_MELS * n_frames;

    /* Find global max of mel_spec */
    float ref_max = state->mel_spec[0];
    for (int i = 1; i < total; ++i)
        if (state->mel_spec[i] > ref_max) ref_max = state->mel_spec[i];

    power_to_db(state->mel_spec, state->mel_db, total,
                ref_max, 1e-10f, 80.0f);

    /* --- Step 6 & 7: Z-score normalize + transpose to row-major --- */
    /* Compute mean and std of mel_db */
    double sum = 0.0, sum2 = 0.0;
    for (int i = 0; i < total; ++i) {
        double v = (double)state->mel_db[i];
        sum += v;
        sum2 += v * v;
    }
    float mean = (float)(sum / total);
    float var = (float)(sum2 / total - (double)mean * (double)mean);
    if (var < 0.0f) var = 0.0f;
    float std_val = sqrtf(var) + 1e-8f;

    /* Transpose from col-major mel_db[f*N_MELS + m] to row-major mel_out[m*n_frames + f] */
    for (int m = 0; m < N_MELS; ++m) {
        for (int f = 0; f < n_frames; ++f) {
            mel_out[m * CNN_TARGET_FRAMES + f] =
                (state->mel_db[f * N_MELS + m] - mean) / std_val;
        }
    }

    /* Zero-pad extra frames if n_frames < CNN_TARGET_FRAMES */
    if (n_frames < CNN_TARGET_FRAMES) {
        float pad_val = (0.0f - mean) / std_val;
        for (int m = 0; m < N_MELS; ++m)
            for (int f = n_frames; f < CNN_TARGET_FRAMES; ++f)
                mel_out[m * CNN_TARGET_FRAMES + f] = pad_val;
    }

    return 0;
}


/* ====================================================================== */
/* Attention preprocessing: energy_trim → RMS → mel → dB → z-score → pad */
/* z-score applied BEFORE padding (only on actual signal frames).         */
/* ====================================================================== */

int repenique_preprocess_attention(repenique_state* state,
                                    const float* audio, int32_t n_samples,
                                    float* mel_out) {
    if (!state)   return -1;
    if (!audio)   return -2;
    if (!mel_out) return -3;
    if (n_samples < 1) return -4;

    /* Ensure scratch buffer for trimmed+normalized audio */
    int max_len = std::min(n_samples, (int32_t)ATT_MAX_SAMPLES);
    if (state->cnn_buf_cap < max_len) {
        float* p = (float*)realloc(state->cnn_buf, sizeof(float) * max_len);
        if (!p) return -5;
        state->cnn_buf = p;
        state->cnn_buf_cap = max_len;
    }

    /* --- Step 1: Energy trim (same as preprocess_cnn) --- */
    const int ETRIM_FRAME = (int)(0.03f * SAMPLE_RATE);
    int trim_start = 0;
    int trim_end = n_samples;

    if (n_samples > ETRIM_FRAME * 3) {
        int n_eframes = n_samples / ETRIM_FRAME;

        float rms_buf[1024];
        float* frame_rms = rms_buf;
        bool heap_rms = false;
        if (n_eframes > 1024) {
            frame_rms = (float*)malloc(sizeof(float) * n_eframes);
            if (!frame_rms) return -5;
            heap_rms = true;
        }

        for (int i = 0; i < n_eframes; ++i) {
            const float* frm = audio + i * ETRIM_FRAME;
            float sum2 = 0.0f;
            for (int j = 0; j < ETRIM_FRAME; ++j)
                sum2 += frm[j] * frm[j];
            frame_rms[i] = sqrtf(sum2 / ETRIM_FRAME);
        }

        float sorted_buf[1024];
        float* rms_sorted = sorted_buf;
        bool heap_sort = false;
        if (n_eframes > 1024) {
            rms_sorted = (float*)malloc(sizeof(float) * n_eframes);
            if (!rms_sorted) { if (heap_rms) free(frame_rms); return -5; }
            heap_sort = true;
        }
        std::memcpy(rms_sorted, frame_rms, sizeof(float) * n_eframes);
        std::sort(rms_sorted, rms_sorted + n_eframes);

        int n_bottom = std::max(1, n_eframes / 5);
        float noise_sum = 0.0f;
        for (int i = 0; i < n_bottom; ++i)
            noise_sum += rms_sorted[i];
        float noise_floor = noise_sum / n_bottom;
        float energy_thresh = std::max(noise_floor * 3.0f, 0.002f);

        if (heap_sort) free(rms_sorted);

        int first_active = -1, last_active = -1;
        for (int i = 0; i < n_eframes; ++i) {
            if (frame_rms[i] > energy_thresh) {
                if (first_active < 0) first_active = i;
                last_active = i;
            }
        }

        if (heap_rms) free(frame_rms);

        if (first_active >= 0) {
            int start_frame = std::max(0, first_active - 1);
            int end_frame = std::min(n_eframes, last_active + 4);
            int new_start = start_frame * ETRIM_FRAME;
            int new_end = std::min(n_samples, end_frame * ETRIM_FRAME);
            if (new_start > 0 || new_end < n_samples) {
                trim_start = new_start;
                trim_end = new_end;
            }
        }
    }

    int trimmed_len = trim_end - trim_start;
    /* Truncate to ATT_MAX_SAMPLES if needed */
    if (trimmed_len > ATT_MAX_SAMPLES) trimmed_len = ATT_MAX_SAMPLES;

    /* --- Step 2: RMS normalize → scratch buffer --- */
    float rms_val = 0.0f;
    for (int i = 0; i < trimmed_len; ++i) {
        float v = audio[trim_start + i];
        rms_val += v * v;
    }
    rms_val = sqrtf(rms_val / trimmed_len);
    float rms_scale = (rms_val > 1e-8f) ? (TARGET_RMS / rms_val) : 1.0f;

    for (int i = 0; i < trimmed_len; ++i)
        state->cnn_buf[i] = audio[trim_start + i] * rms_scale;

    /* --- Step 3: STFT + sparse mel (CNN filterbank: fmin=40, fmax=8000) --- */
    const int32_t padded_len = trimmed_len + N_FFT;
    const int32_t n_frames_expected = 1 + (padded_len - N_FFT) / HOP_LENGTH;

    int rc = repenique_ensure_scratch(state, n_frames_expected, padded_len);
    if (rc != 0) return rc;

    int32_t n_frames = 0;
    compute_stft_and_mel(state, state->cnn_buf, trimmed_len,
                         1.0f, state->mel_sparse_cnn, &n_frames);

    /* --- Step 4: power_to_db with ref=max(S) --- */
    int total = N_MELS * n_frames;

    float ref_max = state->mel_spec[0];
    for (int i = 1; i < total; ++i)
        if (state->mel_spec[i] > ref_max) ref_max = state->mel_spec[i];

    power_to_db(state->mel_spec, state->mel_db, total,
                ref_max, 1e-10f, 80.0f);

    /* --- Step 5: z-score on actual frames ONLY (before padding) --- */
    double sum = 0.0, sum2 = 0.0;
    for (int i = 0; i < total; ++i) {
        double v = (double)state->mel_db[i];
        sum += v;
        sum2 += v * v;
    }
    float mean = (float)(sum / total);
    float var = (float)(sum2 / total - (double)mean * (double)mean);
    if (var < 0.0f) var = 0.0f;
    float std_val = sqrtf(var) + 1e-8f;

    /* --- Step 6: Transpose to row-major + zero-pad to ATT_MAX_FRAMES --- */
    int actual_frames = std::min(n_frames, (int32_t)ATT_MAX_FRAMES);

    /* Zero the entire output first (handles padding) */
    std::memset(mel_out, 0, sizeof(float) * ATT_MEL_SIZE);

    /* Transpose from col-major mel_db[f*N_MELS + m] to row-major mel_out[m*ATT_MAX_FRAMES + f] */
    for (int m = 0; m < N_MELS; ++m) {
        for (int f = 0; f < actual_frames; ++f) {
            mel_out[m * ATT_MAX_FRAMES + f] =
                (state->mel_db[f * N_MELS + m] - mean) / std_val;
        }
    }

    return 0;
}


/* ====================================================================== */
/* Onset envelope (public): para BPM estimation (sem RMS normalize)       */
/* ====================================================================== */

int repenique_onset_envelope(repenique_state* state,
                              const float* audio, int32_t n_samples,
                              float* env_out, int32_t* n_frames_out) {
    if (!state)        return -1;
    if (!audio)        return -2;
    if (!env_out)      return -3;
    if (!n_frames_out) return -3;
    if (n_samples < N_FFT) return -4;

    const int32_t padded_len = n_samples + N_FFT;
    const int32_t n_frames_expected = 1 + (padded_len - N_FFT) / HOP_LENGTH;

    int rc = repenique_ensure_scratch(state, n_frames_expected, padded_len);
    if (rc != 0) return rc;

    /* STFT + mel (Dense filterbank fmin=0 fmax=sr/2, sem RMS normalization) */
    int32_t actual_frames = 0;
    compute_stft_and_mel(state, audio, n_samples, 1.0f,
                         state->mel_sparse, &actual_frames);

    compute_mel_db(state, actual_frames);
    compute_onset_envelope(state, actual_frames);

    std::memcpy(env_out, state->onset_env, sizeof(float) * actual_frames);
    *n_frames_out = actual_frames;

    return 0;
}


/* ====================================================================== */
/* Public API: init, free, version, max_frames                            */
/* ====================================================================== */

repenique_state* repenique_init(void) {
    repenique_state* st = (repenique_state*)calloc(1, sizeof(repenique_state));
    if (!st) return nullptr;

    st->fft_cfg = kiss_fftr_alloc(N_FFT, 0, nullptr, nullptr);
    if (!st->fft_cfg) {
        free(st);
        return nullptr;
    }

    repenique_build_tables(st);
    return st;
}

void repenique_free(repenique_state* state) {
    if (!state) return;
    if (state->fft_cfg)    free(state->fft_cfg);
    if (state->padded)     free(state->padded);
    if (state->stft_mag)   free(state->stft_mag);
    if (state->mel_spec)   free(state->mel_spec);
    if (state->mel_db)     free(state->mel_db);
    if (state->onset_env)  free(state->onset_env);
    if (state->sort_buf)   free(state->sort_buf);
    if (state->onset_buf)  free(state->onset_buf);
    if (state->onset_dbuf) free(state->onset_dbuf);
    /* Free sparse mel weights (Dense + CNN) */
    for (int i = 0; i < N_MELS; ++i) {
        if (state->mel_sparse[i].weights)
            free(state->mel_sparse[i].weights);
        if (state->mel_sparse_cnn[i].weights)
            free(state->mel_sparse_cnn[i].weights);
    }
    if (state->cnn_buf) free(state->cnn_buf);
    free(state);
}

int32_t repenique_max_frames(int32_t n_samples) {
    int32_t padded = n_samples + N_FFT;
    return 1 + (padded - N_FFT) / HOP_LENGTH;
}

const char* repenique_version(void) {
    return VERSION_STR;
}
