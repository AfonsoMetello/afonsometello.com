/**
 * Repenique Classifier DSP — Phase 2 pre-processing.
 *
 * Mel-spec dedicado para os classifiers (rim, voice) e peak picking sobre
 * onset envelope. Independente da API existente (repenique_dsp.h) — não
 * partilha state nem tables. Add-only, zero impacto no Phase 1.
 *
 * Parâmetros (matching torchaudio.transforms.MelSpectrogram do treino):
 *   sample_rate=44100, n_fft=1024, hop_length=441,
 *   n_mels=64, f_min=40, f_max=12000, power=2.0
 *
 * Pipeline classifier mel-spec (matching auto_label_voices_dataset.py):
 *   audio (100ms = 4410 samples)
 *     → STFT power (n_fft=1024, hop=441, hann window)
 *     → mel filterbank (64 bands, fmin=40, fmax=12000)
 *     → log10(mel + 1e-6)
 *     → per-sample normalize (subtract mean, divide std)
 *     → out shape (64, n_frames) where n_frames = WIN_FRAMES = 10
 *
 * Peak picking (matching scipy.signal.find_peaks com height + distance):
 *   onset envelope (frame-rate) → peaks above threshold, min distance frames
 */

#ifndef REPENIQUE_CLASSIFIER_H
#define REPENIQUE_CLASSIFIER_H

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Constants exposed for callers */
#define REPENIQUE_CLF_SR              44100
#define REPENIQUE_CLF_N_FFT           1024
#define REPENIQUE_CLF_HOP             441
#define REPENIQUE_CLF_N_MELS          64
#define REPENIQUE_CLF_WIN_SAMPLES     4410   /* 100ms */
#define REPENIQUE_CLF_WIN_FRAMES      10     /* 4410 / 441 */
#define REPENIQUE_CLF_OUT_SIZE        640    /* 64 mels × 10 frames */

/* Opaque state for classifier mel-spec (FFT plan + tables + scratch) */
typedef struct repenique_classifier_state repenique_classifier_state;

/**
 * Init: aloca FFT plan, constrói hann window e mel filterbank.
 * Retorna NULL se falhar alocação.
 */
repenique_classifier_state* repenique_classifier_init(void);

/**
 * Mel-spec para classifier: input deve ter exatamente WIN_SAMPLES (4410) floats.
 * mel_out deve ter >= OUT_SIZE (640) floats, row-major: mel_out[m * 10 + f].
 *
 * Retorna:
 *   0  = ok
 *  -1  = null state
 *  -2  = null audio
 *  -3  = null mel_out
 *  -4  = audio length != WIN_SAMPLES
 */
int repenique_classifier_mel_spec(repenique_classifier_state* state,
                                   const float* audio,
                                   float* mel_out);

/**
 * Peak picking sobre onset envelope (analogous a scipy.signal.find_peaks).
 *
 * envelope: array de N floats (onset strength per frame)
 * n_frames: tamanho do envelope
 * threshold: peaks must have envelope[i] >= threshold
 * min_distance_frames: min frames between consecutive peaks (>= 1)
 * peaks_out: caller-allocated array, recebe os indices dos peaks
 * peaks_capacity: tamanho do peaks_out array
 *
 * Retorna:
 *   >= 0 : número de peaks escritos em peaks_out
 *   -1   : null envelope
 *   -2   : null peaks_out
 *   -3   : n_frames < 3 ou min_distance < 1
 *   -4   : peaks_capacity insuficiente (escreveu até capacity, retorna -4)
 */
int repenique_pick_peaks(const float* envelope, int32_t n_frames,
                         float threshold, int32_t min_distance_frames,
                         int32_t* peaks_out, int32_t peaks_capacity);

/**
 * Free: liberta FFT plan, tabelas e scratch buffers.
 * Safe com NULL.
 */
void repenique_classifier_free(repenique_classifier_state* state);

#ifdef __cplusplus
}
#endif

#endif /* REPENIQUE_CLASSIFIER_H */
