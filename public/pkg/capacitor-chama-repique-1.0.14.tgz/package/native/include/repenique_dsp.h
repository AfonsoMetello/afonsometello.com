/**
 * Repenique DSP — Extração de 84 features para classificação de chamadas.
 *
 * Port C++ do engine numpy (train_chamadas.py), usando KissFFT para FFT.
 * API extern "C" para bindings universais (Python ctypes, Flutter FFI, etc.).
 *
 * Thread safety: cada thread deve criar o seu próprio repenique_state.
 * Memory: audio é read-only (caller-owned), out é caller-allocated (84 floats).
 */

#ifndef REPENIQUE_DSP_H
#define REPENIQUE_DSP_H

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Opaque state (FFT plans + tabelas pré-computadas + scratch buffers) */
typedef struct repenique_state repenique_state;

/**
 * Init: aloca FFT plan, constrói hann/mel/dct/freq tables.
 * Retorna NULL se falhar alocação.
 */
repenique_state* repenique_init(void);

/**
 * Extrai 84 features. out deve ter >= 84 floats.
 *
 * Retorna:
 *   0  = ok
 *  -1  = null state
 *  -2  = null audio
 *  -3  = null out
 *  -4  = n_samples < 2048 (mínimo para 1 frame STFT)
 *  -5  = alloc fail (scratch buffers)
 */
int repenique_extract(repenique_state* state,
                      const float* audio, int32_t n_samples,
                      float* out);

/**
 * Pré-processa áudio para CNN: energy_trim → RMS norm → pad/truncate →
 * mel spectrogram (fmin=40, fmax=8000) → power_to_db(ref=max) → z-score.
 *
 * mel_out deve ter >= 38656 floats (128 × 302, row-major).
 * mel_out[mel * 302 + frame].
 *
 * Retorna:
 *   0  = ok
 *  -1  = null state
 *  -2  = null audio
 *  -3  = null mel_out
 *  -4  = n_samples < 2048
 *  -5  = alloc fail
 */
int repenique_preprocess_cnn(repenique_state* state,
                              const float* audio, int32_t n_samples,
                              float* mel_out);

/**
 * Pré-processa áudio para modelo Attention: energy_trim → RMS norm →
 * mel spectrogram (fmin=40, fmax=8000) → power_to_db(ref=max) →
 * z-score (antes do padding) → zero-pad/truncate a 736 frames.
 *
 * mel_out deve ter >= 93888 floats (128 × 736, row-major).
 * mel_out[mel * 736 + frame].
 *
 * Retorna:
 *   0  = ok
 *  -1  = null state
 *  -2  = null audio
 *  -3  = null mel_out
 *  -4  = n_samples < 2048
 *  -5  = alloc fail
 */
int repenique_preprocess_attention(repenique_state* state,
                                    const float* audio, int32_t n_samples,
                                    float* mel_out);

/**
 * Calcula onset strength envelope (sem RMS normalize, para BPM estimation).
 *
 * env_out deve ter >= repenique_max_frames(n_samples) floats.
 * n_frames_out recebe o número real de frames escritos.
 *
 * Retorna:
 *   0  = ok
 *  -1  = null state
 *  -2  = null audio
 *  -3  = null env_out ou n_frames_out
 *  -4  = n_samples < 2048
 *  -5  = alloc fail
 */
int repenique_onset_envelope(repenique_state* state,
                              const float* audio, int32_t n_samples,
                              float* env_out, int32_t* n_frames_out);

/**
 * Helper: calcula o número de frames STFT para dado n_samples.
 * n_frames = 1 + (n_samples + N_FFT - 1) / HOP_LENGTH
 * (com center-padding de N_FFT/2 em cada lado)
 */
int32_t repenique_max_frames(int32_t n_samples);

/**
 * Free: liberta FFT plan, tabelas e scratch buffers.
 * Safe to call com NULL.
 */
void repenique_free(repenique_state* state);

/**
 * Version string (compile-time).
 */
const char* repenique_version(void);

#ifdef __cplusplus
}
#endif

#endif /* REPENIQUE_DSP_H */
