/**
 * Repenique Onset-CNN DSP — Phase 2 onset detection pre-processing.
 *
 * Mel-spec dedicado para o CNN onset detector treinado em
 * scripts/onset_cnn_inference.py. Independente das duas APIs existentes
 * (repenique_dsp.h Phase 1 attention; repenique_classifier.h Phase 2
 * rim/voice classifiers) — params específicos:
 *
 *   torchaudio.transforms.MelSpectrogram(
 *       sample_rate=44100, n_fft=2048, hop_length=441,
 *       n_mels=128, f_min=40, f_max=8000, power=2.0,
 *   )
 *
 * Pipeline (matching scripts/onset_cnn_inference.py:_to_logmel):
 *   audio (2s = 88200 samples)
 *     → STFT power (n_fft=2048, hop=441, hann window, center=True reflect pad)
 *     → mel filterbank (128 bands, fmin=40, fmax=8000, HTK)
 *     → log10(mel + 1e-6)
 *     → per-sample normalize (subtract mean, divide std)
 *     → out shape (128, n_frames) where n_frames = WIN_FRAMES = 200
 *
 * O TFLite onset_cnn.tflite tem input fixo (1, 128, 200) — esta API só
 * computa a janela 2s. Sliding/concat para áudio mais comprido é feito no
 * lado Swift.
 */

#ifndef REPENIQUE_ONSET_CNN_H
#define REPENIQUE_ONSET_CNN_H

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Constants exposed for callers */
#define REPENIQUE_ONSET_SR              44100
#define REPENIQUE_ONSET_N_FFT           2048
#define REPENIQUE_ONSET_HOP             441      /* 10ms @ 44100 */
#define REPENIQUE_ONSET_N_MELS          128
#define REPENIQUE_ONSET_WIN_SAMPLES     88200    /* 2s */
#define REPENIQUE_ONSET_WIN_FRAMES      200      /* 2s @ 100Hz */
#define REPENIQUE_ONSET_OUT_SIZE        25600    /* 128 mels × 200 frames */

/* Opaque state for onset CNN mel-spec (FFT plan + tables + scratch) */
typedef struct repenique_onset_state repenique_onset_state;

/**
 * Init: aloca FFT plan (n_fft=2048), constrói hann window e mel filterbank
 * (128 mels, fmin=40, fmax=8000, HTK).
 * Retorna NULL se falhar alocação.
 */
repenique_onset_state* repenique_onset_init(void);

/**
 * Mel-spec para CNN onset: input deve ter exatamente WIN_SAMPLES (88200) floats.
 * mel_out deve ter >= OUT_SIZE (25600) floats, row-major: mel_out[m * 200 + f].
 *
 * Retorna:
 *   0  = ok
 *  -1  = null state
 *  -2  = null audio
 *  -3  = null mel_out
 */
int repenique_onset_mel_spec(repenique_onset_state* state,
                              const float* audio,
                              float* mel_out);

/**
 * Free: liberta FFT plan, tabelas e scratch buffers.
 * Safe com NULL.
 */
void repenique_onset_free(repenique_onset_state* state);

#ifdef __cplusplus
}
#endif

#endif /* REPENIQUE_ONSET_CNN_H */
